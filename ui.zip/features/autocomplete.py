import os
import re
import time
import threading
import ast
import importlib.util
from typing import Dict, Set, List, Any

from PySide6.QtCore import QThread, Signal

from ..utils.cache_manager import ModuleCacheManager
from ..utils.language_syntax import LanguageSyntaxManager
class AutoCompleteWorker(QThread):
    finished = Signal(list)  # suggestions
    progress = Signal(str)  # progress update
    loading_state = Signal(bool)  # True=loading, False=done

    def __init__(self, text, cursor_position, file_path, project_path, selected_text=""):
        super().__init__()
        self.text = text
        self.cursor_position = cursor_position
        self.file_path = file_path
        self.project_path = project_path
        self.selected_text = selected_text
        self._is_running = True
        # Cache para melhor performance
        self._keyword_cache = None
        self._builtin_cache = None
        self._module_cache = {}  # Cache para módulos

    def stop(self):
        self._is_running = False
        self.terminate()

    def run(self):
        if not self._is_running:
            return

        try:
            # Emite sinal de carregamento
            self.loading_state.emit(True)
            self.progress.emit("🔍 Analisando código...")

            # Preload se não feito
            module_cache_manager.preload_all_project_modules(self.project_path, self.file_path)

            # Resposta ultra-rápida com cache
            suggestions = self.get_instant_suggestions()

            if self._is_running:
                self.progress.emit("✅ Sugestões carregadas!")
                self.loading_state.emit(False)
                self.finished.emit(suggestions)

        except Exception as e:
            if self._is_running:
                self.progress.emit(f"❌ Erro: {str(e)}")
                self.loading_state.emit(False)
                self.finished.emit([])

    def get_instant_suggestions(self):
        """Sugestões instantâneas com suporte multi-linguagem"""
        suggestions = set()

        # Determina a linguagem atual
        language = self.detect_language()

        # 1. Sugestões da sintaxe da linguagem
        syntax_suggestions = language_syntax_manager.get_suggestions(language)
        suggestions.update(syntax_suggestions)

        # 2. Contexto básico
        lines = self.text[:self.cursor_position].split('\n')
        current_line = lines[-1] if lines else ""
        current_word = self.get_current_word_fast(current_line)

        # 3. Para Python, usa o cache manager
        if language == 'python':
            # Palavras-chave com cache
            if self._keyword_cache is None:
                self._keyword_cache = self.get_all_keywords()
            suggestions.update(self._keyword_cache)

            # Built-ins com cache
            if self._builtin_cache is None:
                self._builtin_cache = self.get_all_builtins()
            suggestions.update(self._builtin_cache)

            # Análise local
            self.progress.emit("📝 Analisando definições locais...")
            local_defs = self.get_local_definitions_instant()
            suggestions.update(local_defs)

            # Módulos importados
            self.progress.emit("📦 Analisando imports...")
            module_suggestions = self.get_module_suggestions_fast(current_word)
            suggestions.update(module_suggestions)

        # 4. Para outras linguagens, usa sintaxe específica
        else:
            self.progress.emit(f"🔍 Analisando {language}...")
            lang_specific = self.get_language_specific_suggestions(language, current_word)
            suggestions.update(lang_specific)

        # 5. Filtro por palavra atual
        if current_word:
            if '.' in current_word:
                # Cadeia: usa syntax manager
                chain_base = current_word.rsplit('.', 1)[0]
                chain_methods = language_syntax_manager.get_chain_suggestions(language, chain_base)
                filtered = [s for s in chain_methods if s.lower().startswith(current_word.lower().rsplit('.', 1)[1])]
                suggestions.update(filtered)
            else:
                filtered = [s for s in suggestions if s.lower().startswith(current_word.lower())]
                suggestions = set(filtered)

        return sorted(list(suggestions))[:20]

    def detect_language(self) -> str:
        """Detecta a linguagem baseada na extensão do arquivo"""
        if not self.file_path:
            return 'python'  # default

        ext = os.path.splitext(self.file_path)[1].lower()

        language_map = {
            '.py': 'python',
            '.js': 'javascript', '.jsx': 'javascript', '.mjs': 'javascript',
            '.html': 'html', '.htm': 'html',
            '.css': 'css', '.scss': 'css', '.sass': 'css',
            '.sql': 'sql',
            '.java': 'java',
            '.cpp': 'cpp', '.cc': 'cpp', '.cxx': 'cpp', '.h': 'cpp', '.hpp': 'cpp',
            '.cs': 'csharp',
            '.php': 'php',
            '.rb': 'ruby',
            '.go': 'go',
            '.rs': 'rust',
            '.swift': 'swift',
            '.kt': 'kotlin', '.kts': 'kotlin',
            '.ts': 'typescript', '.tsx': 'typescript',
            '.yaml': 'yaml', '.yml': 'yaml',
            '.xml': 'xml',
            '.md': 'markdown'
        }

        return language_map.get(ext, 'python')

    def get_language_specific_suggestions(self, language: str, current_word: str) -> Set[str]:
        """Sugestões específicas para cada linguagem"""
        suggestions = set()

        if language == 'html':
            # Sugere tags e atributos baseados no contexto
            if current_word.startswith('<'):
                suggestions.update(language_syntax_manager.syntax_data['html']['tags'])
            elif '=' in current_line:
                suggestions.update(language_syntax_manager.syntax_data['html']['attributes'].get('global', []))

        elif language == 'css':
            # Sugere propriedades e valores
            if current_line.strip().endswith(':'):
                suggestions.update(language_syntax_manager.syntax_data['css']['values'].get('color', []))
                suggestions.update(language_syntax_manager.syntax_data['css']['values'].get('size', []))
            else:
                suggestions.update(language_syntax_manager.syntax_data['css']['properties'])

        elif language == 'javascript':
            # Sugere APIs globais e métodos
            suggestions.update(language_syntax_manager.syntax_data['javascript']['global_functions'])

        return suggestions
    def get_module_suggestions_fast(self, current_word: str = ""):
        """Sugestões de módulos importados com cache - CORRIGIDO"""
        suggestions = set()

        try:
            # Analisa imports no código
            imports = self.parse_imports_fast()

            for module_name in imports:
                # Usa o cache manager para obter métodos
                self.progress.emit(f"📚 Carregando {module_name}...")
                module_methods = module_cache_manager.get_module_methods(
                    module_name,
                    self.file_path,
                    self.project_path
                )
                suggestions.update(module_methods)

                # Também adiciona o próprio nome do módulo
                suggestions.add(module_name)

                # Se current_word tem ., sugere chains - CORREÇÃO: verificação segura
                if '.' in current_word and current_word.startswith(module_name + '.'):
                    chain = current_word.split('.', 1)[0]
                    try:
                        chain_methods = module_cache_manager.get_chain_methods(chain, self.file_path, self.project_path)
                        suggestions.update(chain_methods)
                    except Exception as e:
                        print(f"Erro em chain methods para {chain}: {e}")
                        # Fallback: métodos comuns baseados no padrão
                        fallback_methods = self._get_fallback_chain_methods(chain)
                        suggestions.update(fallback_methods)

        except Exception as e:
            print(f"Erro em get_module_suggestions_fast: {e}")

        return suggestions

    def _get_fallback_chain_methods(self, chain: str) -> Set[str]:
        """Fallback para quando o chain method falha"""
        common_chains = {
            'os.path': ['join()', 'exists()', 'dirname()', 'basename()', 'abspath()'],
            'sys.path': ['append()', 'insert()', 'remove()'],
            'json.dumps': ['encode()'],
            'json.loads': ['decode()'],
            're.compile': ['match()', 'search()', 'findall()', 'sub()'],
            'datetime.datetime': ['now()', 'today()', 'strftime()', 'strptime()'],
        }
        return set(common_chains.get(chain, []))

    def parse_imports_fast(self):
        """Analisa imports de forma rápida com regex - MELHORADO"""
        imports = set()

        # Padrões regex para imports
        import_patterns = [
            r'import\s+([a-zA-Z_][a-zA-Z0-9_]*(\.[a-zA-Z_][a-zA-Z0-9_]*)*)',
            r'from\s+([a-zA-Z_][a-zA-Z0-9_]*(\.[a-zA-Z_][a-zA-Z0-9_]*)*)\s+import',
            r'import\s+([a-zA-Z_][a-zA-Z0-9_]*)\s+as\s+([a-zA-Z_][a-zA-Z0-9_]*)',
            r'from\s+([a-zA-Z_][a-zA-Z0-9_]*)\s+import\s+([a-zA-Z_][a-zA-Z0-9_]*)'
        ]

        for pattern in import_patterns:
            matches = re.findall(pattern, self.text)
            for match in matches:
                if isinstance(match, tuple):
                    for item in match:
                        if item and item not in ['', ' ']:
                            imports.add(item)
                else:
                    if match and match not in ['', ' ']:
                        imports.add(match)

        return imports

    def get_current_word_fast(self, current_line):
        """Extrai palavra atual de forma ultra-rápida - MELHORADO PARA CADEIAS"""
        if not current_line.strip():
            return ""

        # Busca reversa simples para palavra completa incluindo chains
        line = current_line[:current_line.rfind(' ')+1 if ' ' in current_line else len(current_line)].rstrip()

        # Extrai a última palavra ou chain antes do cursor
        words = re.split(r'[\s\(\)\[\]\{\}]', line)[-1].rstrip()
        if words.endswith('.'):
            # Para "os." retorna "os." para sugerir métodos
            return words
        return words

    def get_selected_suggestions_fast(self, selected_text):
        """Sugestões rápidas para texto selecionado"""
        selected_clean = selected_text.strip()
        suggestions = []

        if not selected_clean:
            return suggestions

        # Resposta instantânea baseada no tipo
        if selected_clean.replace('.', '').replace('-', '').isdigit():
            # Número
            suggestions = [
                f"abs({selected_clean})",
                f"round({selected_clean})",
                f"str({selected_clean})",
                f"int({selected_clean})",
            ]
        elif selected_clean.startswith(('"', "'")):
            # String
            suggestions = [
                f"len({selected_clean})",
                f"str({selected_clean})",
                f"{selected_clean}.upper()",
                f"{selected_clean}.lower()",
                f"{selected_clean}.strip()",
                f"{selected_clean}.split()",
            ]
        elif re.match(r'^[a-zA-Z_][a-zA-Z0-9_]*$', selected_clean):
            # Variável/função
            suggestions = [
                f"len({selected_clean})",
                f"str({selected_clean})",
                f"int({selected_clean})",
                f"float({selected_clean})",
                f"print({selected_clean})",
                f"type({selected_clean})",
            ]

        return suggestions[:8]

    def get_local_definitions_instant(self):
        """Extrai definições locais instantaneamente com regex - MELHORADO"""
        definitions = set()

        # Regex ultra-rápidas para funções e classes
        func_matches = re.findall(r'def\s+([a-zA-Z_][a-zA-Z0-9_]*)', self.text)
        class_matches = re.findall(r'class\s+([a-zA-Z_][a-zA-Z0-9_]*)', self.text)
        var_matches = re.findall(r'^(\s*)([a-zA-Z_][a-zA-Z0-9_]*)\s*=', self.text, re.MULTILINE)

        definitions.update([f"{f}()" for f in func_matches])
        definitions.update(class_matches)

        # Filtra variáveis para evitar muito ruído
        for _, var in var_matches:
            if len(var) > 2 and not var.startswith('_'):  # Filtra variáveis muito curtas e privadas
                definitions.add(var)

        return definitions

    def get_all_keywords(self):
        """Todas palavras-chave Python"""
        return {
            "if", "else", "elif", "for", "while", "break", "continue", "pass", "return",
            "try", "except", "finally", "raise", "def", "class", "lambda", "global",
            "nonlocal", "import", "from", "as", "and", "or", "not", "in", "is",
            "True", "False", "None", "with", "yield", "assert", "del", "async", "await"
        }

    def get_all_builtins(self):
        """Built-ins mais comuns"""
        return {
            "print", "len", "str", "int", "float", "list", "dict", "set", "tuple",
            "range", "input", "open", "type", "sum", "min", "max", "abs", "round",
            "sorted", "reversed", "enumerate", "zip", "map", "filter", "any", "all",
            "bool", "chr", "ord", "dir", "help", "id", "isinstance", "issubclass",
            "getattr", "setattr", "hasattr", "vars", "locals", "globals"
        }

    def get_import_suggestions(self):
        """Sugestões para imports"""
        common_modules = [
            'os', 'sys', 'json', 'tkinter', 're', 'datetime', 'math', 'random',
            'subprocess', 'shutil', 'glob', 'ast', 'inspect', 'importlib',
            'platform', 'time', 'pathlib', 'collections', 'itertools', 'functools'
        ]
        return common_modules

    def get_context_suggestions(self, current_line, current_word):
        """Sugestões baseadas no contexto - MELHORADO PARA CADEIAS"""
        suggestions = set()
        # Sugestões comuns baseadas em palavra atual
        context_map = {
            'if': ['else', 'elif'],
            'for': ['in', 'range', 'enumerate'],
            'def': ['pass', 'return'],
            'class': ['def', 'pass'],
            'import': ['os', 'sys', 'json'],
            '.': ['append()', 'get()', 'upper()', 'lower()']  # Comum após ponto
        }
        for key, vals in context_map.items():
            if key in current_word.lower():
                suggestions.update(vals)
        return suggestions
class DefinitionVisitor(ast.NodeVisitor):
    def __init__(self):
        self.definitions = set()
        self.imported_modules = set()
        self.current_class = None
        self.import_statements = []  # Armazena imports para análise posterior

    def visit_ClassDef(self, node):
        self.current_class = node.name
        self.definitions.add(node.name)
        self.generic_visit(node)
        self.current_class = None

    def visit_FunctionDef(self, node):
        if self.current_class:
            self.definitions.add(f"{self.current_class}.{node.name}()")
        else:
            self.definitions.add(f"{node.name}()")
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node):
        if self.current_class:
            self.definitions.add(f"{self.current_class}.{node.name}()")
        else:
            self.definitions.add(f"{node.name}()")
        self.generic_visit(node)

    def visit_Assign(self, node):
        for target in node.targets:
            if isinstance(target, ast.Name):
                self.definitions.add(target.id)
            elif isinstance(target, ast.Attribute):
                self.definitions.add(f"{target.value.id}.{target.attr}" if isinstance(target.value, ast.Name) else target.attr)
        self.generic_visit(node)

    def visit_AnnAssign(self, node):
        if isinstance(node.target, ast.Name):
            self.definitions.add(node.target.id)
        self.generic_visit(node)

    def visit_Import(self, node):
        for alias in node.names:
            module_name = alias.name.split('.')[0]
            self.definitions.add(module_name)
            self.imported_modules.add(module_name)
            self.import_statements.append(alias.name)
        self.generic_visit(node)

    def visit_ImportFrom(self, node):
        if node.module:
            self.definitions.add(node.module)
            self.imported_modules.add(node.module)
            self.import_statements.append(f"from {node.module} import ...")
        for alias in node.names:
            self.definitions.add(alias.name)
        self.generic_visit(node)
class SafeDefinitionVisitor(ast.NodeVisitor):
    """Visitor AST seguro com tratamento de erros"""

    def __init__(self):
        self.definitions = set()

    def visit_ClassDef(self, node):
        try:
            self.definitions.add(node.name)
            self.generic_visit(node)
        except:
            pass

    def visit_FunctionDef(self, node):
        try:
            self.definitions.add(f"{node.name}()")
            self.generic_visit(node)
        except:
            pass

    def visit_Import(self, node):
        try:
            for alias in node.names:
                module_name = alias.name.split('.')[0]
                self.definitions.add(module_name)
            self.generic_visit(node)
        except:
            pass

    def visit_ImportFrom(self, node):
        try:
            if node.module:
                self.definitions.add(node.module)
            for alias in node.names:
                self.definitions.add(alias.name)
            self.generic_visit(node)
        except:
            pass
