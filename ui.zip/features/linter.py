class LinterWorker(QThread):
    finished = Signal(dict, list)  # errors, messages

    def __init__(self, file_path, python_exec, project_path):
        super().__init__()
        self.file_path = file_path
        self.python_exec = python_exec
        self.project_path = project_path
        self._is_running = True

    def stop(self):
        self._is_running = False
        self.terminate()

    def run(self):
        if not self._is_running or not self.file_path:
            return

        errors = {}
        lint_messages = []

        try:
            # Try pylint first with corrected enables
            pylint_cmd = [
                self.python_exec, '-m', 'pylint',
                '--output-format=json',
                '--reports=n',  # No reports
                '--disable=all',
                '--enable=E,W,fatal',
                self.file_path
            ]

            cwd = self.project_path if self.project_path else os.path.dirname(self.file_path)
            result = subprocess.run(
                pylint_cmd,
                capture_output=True,
                text=True,
                cwd=cwd,
                encoding='utf-8',
                timeout=5  # Reduced timeout
            )

            if result.returncode in [0, 1, 2, 4, 8, 16, 32] and result.stdout.strip():
                try:
                    lines = result.stdout.strip().split('\n')
                    for line in lines:
                        if not self._is_running:
                            return
                        if line.strip():
                            try:
                                issue = json.loads(line.strip())
                                if 'line' in issue and issue['line'] > 0:
                                    line_num = issue['line'] - 1
                                    msg = issue.get('message', 'No message')
                                    symbol = issue.get('symbol', 'unknown')
                                    msg_type = issue.get('type', 'warning')
                                    error_type = 'error' if msg_type == 'error' else 'warning'

                                    if line_num not in errors:
                                        errors[line_num] = []
                                    errors[line_num].append({
                                        'type': error_type,
                                        'msg': msg,
                                        'symbol': symbol
                                    })
                                    lint_messages.append(f"Line {issue['line']}: {msg} ({symbol})")
                            except json.JSONDecodeError:
                                continue
                except json.JSONDecodeError:
                    pass  # Silently ignore JSON errors

        except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
            # Silently fail - we don't want to spam messages for missing linters
            pass

        if self._is_running:
            self.finished.emit(errors, lint_messages)
