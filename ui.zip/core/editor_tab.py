
import os
import subprocess
import shutil
import glob
import json
import inspect
import importlib.util
import ast
import platform
import time
import re
from typing import Dict, Set, List, Any
import threading
import textwrap

from PySide6.QtWidgets import (
    QApplication, QMainWindow, QDockWidget, QPlainTextEdit,
    QFileSystemModel, QTreeView, QTabWidget, QToolBar,
    QFileDialog, QInputDialog, QMessageBox, QComboBox,
    QMenu, QSplitter, QVBoxLayout, QWidget, QListWidget, QListWidgetItem,
    QStyledItemDelegate, QDialog, QVBoxLayout as QVBoxLayoutDialog, QLabel, QPushButton,
    QCompleter, QProgressBar, QHBoxLayout, QLineEdit
)
from PySide6.QtGui import (
    QAction, QPalette, QColor, QFont, QSyntaxHighlighter, QTextCharFormat, QTextCursor,
    QKeyEvent, QTextBlockUserData, QTextOption, QPainter, QFontDatabase, QGuiApplication, QShortcut
)
from PySide6.QtCore import Qt, QDir, QRegularExpression, QProcess, QTimer, QModelIndex, QThread, Signal, \
    QStringListModel, QSize
import os
import json
from typing import Dict, List, Set, Any


class EditorTab(QWidget):
    def __init__(self, file_path=None, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self.file_path = file_path

        # Obter conteúdo do arquivo se existir
        initial_text = ""
        if file_path and os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    initial_text = f.read()
            except Exception:
                initial_text = ""

        # CORREÇÃO: Passar todos os parâmetros obrigatórios
        self.editor = CodeEditor(
            text=initial_text,
            cursor_position=0,
            file_path=file_path,
            project_path=self.get_project_path()
        )

        # CORREÇÃO ADICIONAL: Garantir que o tab seja 4 espaços
        font = QFont("Monospace", 12)
        self.editor.setFont(font)
        font_metrics = self.editor.fontMetrics()
        tab_width = font_metrics.horizontalAdvance(' ') * 4  # 4 espaços
        self.editor.setTabStopDistance(tab_width)

        # Use o MultiLanguageHighlighter em vez do PythonHighlighter
        self.highlighter = MultiLanguageHighlighter(self.editor.document())
        if file_path:
            self.highlighter.set_language(file_path)

        self.editor.setWordWrapMode(QTextOption.NoWrap)

        # Resto do código permanece igual...
        self.lint_timer = QTimer(self)
        self.lint_timer.setSingleShot(True)
        self.lint_timer.timeout.connect(self.start_linting)

        self.linter_worker = None
        self.last_lint_content = initial_text

        # Connect signals
        self.editor.textChanged.connect(self.schedule_linting)
        self.editor.cursorPositionChanged.connect(self.update_line_numbers)
        self.editor.verticalScrollBar().valueChanged.connect(self.update_line_numbers)

        # Line number area
        self.line_number_area = LineNumberArea(self.editor)
        layout.addWidget(self.editor)
        self.setLayout(layout)

        self.update_line_numbers()

        # Set viewport margins to shift text to the right
        self.editor.setViewportMargins(self.line_number_area.width() + 10, 0, 0, 0)

    def get_project_path(self):
        """Obtém o caminho do projeto do IDE pai"""
        ide = self.get_ide()
        return ide.project_path if ide else ""

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.line_number_area.setGeometry(0, 0, self.line_number_area.width(), self.height())

    def update_line_numbers(self):
        self.line_number_area.update_line_numbers()

    def schedule_linting(self):
        """Schedule linting with debounce and content change check"""
        current_content = self.editor.toPlainText()

        # Only lint if content actually changed and it's a Python file
        if (current_content != self.last_lint_content and
                self.file_path and
                self.file_path.endswith('.py')):
            self.lint_timer.start(2000)  # Increased to 2 seconds

    def start_linting(self):
        """Start linting in a separate thread"""
        if not self.file_path or not self.file_path.endswith('.py'):
            return

        ide = self.get_ide()
        if not ide:
            return

        # Stop previous worker if running
        if self.linter_worker and self.linter_worker.isRunning():
            self.linter_worker.stop()

        # Save file and update last content
        try:
            current_content = self.editor.toPlainText()
            with open(self.file_path, 'w', encoding='utf-8') as f:
                f.write(current_content)
            self.last_lint_content = current_content
        except Exception:
            return

        # Start new worker
        self.linter_worker = LinterWorker(
            self.file_path,
            ide.get_python_executable(),
            ide.project_path
        )
        self.linter_worker.finished.connect(self.on_linting_finished)
        self.linter_worker.start()

    def on_linting_finished(self, errors, lint_messages):
        """Handle linting results from worker thread"""
        ide = self.get_ide()
        if not ide:
            return

        # Apply errors to document
        doc = self.editor.document()
        block_count = doc.blockCount()

        # Clear previous errors from all blocks
        for i in range(block_count):
            block = doc.findBlockByLineNumber(i)
            if block.isValid():
                block.setUserData(ErrorData([]))

        # Apply new errors
        for line_num, line_errors in errors.items():
            if line_num < block_count:
                block = doc.findBlockByLineNumber(line_num)
                if block.isValid():
                    data = ErrorData(line_errors)
                    block.setUserData(data)

        # Update problems list
        if ide.problems_list:
            ide.problems_list.clear()
            for msg in lint_messages:
                item = QListWidgetItem(msg)

                # Extract line number safely
                line_num = '0'
                if 'Line' in msg and ':' in msg:
                    try:
                        line_part = msg.split('Line')[1].split(':')[0].strip()
                        line_num = line_part
                    except:
                        pass

                data = {
                    'file': self.file_path,
                    'line': line_num,
                    'type': 'error' if 'error' in msg.lower() else 'warning'
                }
                item.setData(Qt.UserRole, data)
                ide.problems_list.addItem(item)

        # Also update lint_text for additional info
        if ide.lint_text:
            if lint_messages:
                ide.lint_text.setPlainText('\n'.join(lint_messages))
            else:
                ide.lint_text.setPlainText("No lint issues found.")

        # Rehighlight with new errors
        self.highlighter.rehighlight()

    def get_ide(self):
        """Find and return the parent IDE instance"""
        parent = self.parent()
        while parent and not isinstance(parent, IDE):
            if hasattr(parent, 'parent'):
                parent = parent.parent()
            else:
                parent = None
        return parent

    def rehighlight(self):
        self.highlighter.rehighlight()
