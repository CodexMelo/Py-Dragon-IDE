import os
import subprocess
import shutil
import glob
import json
import inspect
import importlib.util
import ast
import platform
import time
import re
from typing import Dict, Set, List, Any
import threading
import textwrap

from PySide6.QtWidgets import (
    QApplication, QMainWindow, QDockWidget, QPlainTextEdit,
    QFileSystemModel, QTreeView, QTabWidget, QToolBar,
    QFileDialog, QInputDialog, QMessageBox, QComboBox,
    QMenu, QSplitter, QVBoxLayout, QWidget, QListWidget, QListWidgetItem,
    QStyledItemDelegate, QDialog, QVBoxLayout as QVBoxLayoutDialog, QLabel, QPushButton,
    QCompleter, QProgressBar, QHBoxLayout, QLineEdit
)
from PySide6.QtGui import (
    QAction, QPalette, QColor, QFont, QSyntaxHighlighter, QTextCharFormat, QTextCursor,
    QKeyEvent, QTextBlockUserData, QTextOption, QPainter, QFontDatabase, QGuiApplication, QShortcut
)
from PySide6.QtCore import Qt, QDir, QRegularExpression, QProcess, QTimer, QModelIndex, QThread, Signal, \
    QStringListModel, QSize
import os
import json
from typing import Dict, List, Set, Any

class IDE(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setup_ui()
        self.setup_connections()
        self.setup_shortcuts()

        # Configuração global de exceções (movida para fora do setup_ui)
        def exception_hook(exctype, value, tb):
            print("ERRO GLOBAL:", exctype, value)
            traceback.print_exception(exctype, value, tb)
            sys.__excepthook__(exctype, value, tb)  # Chama o original
        sys.excepthook = exception_hook

    def setup_ui(self):
        """Configura a interface do usuário de forma otimizada"""
        self.setWindowTitle("Py Dragon Studio IDE")
        self.setGeometry(100, 100, 1400, 900)

        # Variáveis de estado
        self.current_file = None
        self.project_path = None
        self.python_path = sys.executable
        self.venv_path = None
        self.current_font = "Consolas"  # Fonte melhor para programação
        self.clipboard_path = None
        self.is_cut = False

        # Componentes que precisam ser inicializados
        self.shell_process = QProcess(self)
        self.problems_list = None

        # Tema escuro otimizado
        self.set_dark_theme_optimized()

        # Layout principal
        self.setup_central_widget()
        self.setup_docks()
        self.setup_menu()
        self.setup_toolbar()
        self.setup_statusbar()

        # Inicialização de componentes
        self.start_shell()
        self.check_python_version()

    def setup_central_widget(self):
        """Configura o widget central com tabs"""
        self.tab_widget = QTabWidget()
        self.tab_widget.setTabsClosable(True)
        self.tab_widget.setMovable(True)
        self.tab_widget.setDocumentMode(True)
        self.tab_widget.setStyleSheet("""
            QTabWidget::pane {
                border: 1px solid #2d2d30;
                background-color: #1e1e1e;
            }
            QTabBar::tab {
                background-color: #2d2d30;
                color: #cccccc;
                padding: 8px 16px;
                margin-right: 2px;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
            }
            QTabBar::tab:selected {
                background-color: #1e1e1e;
                border-bottom: 2px solid #569cd6;
            }
            QTabBar::tab:hover {
                background-color: #383838;
            }
        """)

        self.setCentralWidget(self.tab_widget)

    def setup_docks(self):
        """Configura os docks de forma organizada"""
        # Dock esquerdo - Explorer e Problems
        self.setup_left_dock()

        # Dock direito - Minimap
        self.setup_right_dock()

        # Dock inferior - Output e Terminal
        self.setup_bottom_dock()

    def setup_left_dock(self):
        """Configura o dock esquerdo com Explorer e Problems"""
        left_dock = QDockWidget("Explorer", self)
        left_dock.setFeatures(QDockWidget.DockWidgetMovable | QDockWidget.DockWidgetFloatable)
        left_dock.setMaximumWidth(250)  # A: Deixar mais fina, apenas o necessário

        # Container para múltiplas abas no dock esquerdo
        left_tabs = QTabWidget()
        left_tabs.setTabPosition(QTabWidget.West)

        # File Explorer
        self.setup_file_explorer(left_tabs)

        # Problems List
        self.setup_problems_widget(left_tabs)

        left_dock.setWidget(left_tabs)
        self.addDockWidget(Qt.LeftDockWidgetArea, left_dock)

    def setup_file_explorer(self, parent_tabs):
        """Configura o explorador de arquivos"""
        explorer_widget = QWidget()
        explorer_layout = QVBoxLayout(explorer_widget)

        # Barra de ferramentas do explorer
        explorer_toolbar = QToolBar()
        explorer_toolbar.setIconSize(QSize(16, 16))

        # Botões do explorer
        self.refresh_explorer_btn = QAction("🔄", self)
        self.new_file_btn = QAction("📄", self)
        self.new_folder_btn = QAction("📁", self)

        explorer_toolbar.addAction(self.refresh_explorer_btn)
        explorer_toolbar.addAction(self.new_file_btn)
        explorer_toolbar.addAction(self.new_folder_btn)

        explorer_layout.addWidget(explorer_toolbar)

        # Modelo de arquivos
        self.file_model = QFileSystemModel()
        self.file_model.setRootPath(QDir.homePath())

        # Tree view
        self.file_tree = QTreeView()
        self.file_tree.setModel(self.file_model)
        self.file_tree.setRootIndex(self.file_model.index(QDir.homePath()))
        self.file_tree.setAnimated(True)
        self.file_tree.setIndentation(15)
        self.file_tree.setSortingEnabled(True)

        # Ocultar colunas desnecessárias
        self.file_tree.hideColumn(1)  # Tamanho
        self.file_tree.hideColumn(2)  # Tipo
        self.file_tree.hideColumn(3)  # Data modificação

        explorer_layout.addWidget(self.file_tree)

        parent_tabs.addTab(explorer_widget, "📁 Explorer")

    def setup_problems_widget(self, parent_tabs):
        """Configura a lista de problemas"""
        problems_widget = QWidget()
        problems_layout = QVBoxLayout(problems_widget)

        # Barra de ferramentas dos problemas
        problems_toolbar = QToolBar()
        problems_toolbar.setIconSize(QSize(16, 16))

        self.clear_problems_btn = QAction("🗑️", self)
        self.run_lint_btn = QAction("🔍", self)

        problems_toolbar.addAction(self.clear_problems_btn)
        problems_toolbar.addAction(self.run_lint_btn)

        problems_layout.addWidget(problems_toolbar)

        # Lista de problemas
        self.problems_list = QListWidget()
        self.problems_list.setItemDelegate(ProblemsDelegate())
        self.problems_list.setAlternatingRowColors(True)

        problems_layout.addWidget(self.problems_list)

        parent_tabs.addTab(problems_widget, "⚠️ Problems")

    def setup_right_dock(self):
        """Configura o dock direito com minimap"""
        right_dock = QDockWidget("Minimap", self)
        right_dock.setFeatures(QDockWidget.DockWidgetMovable | QDockWidget.DockWidgetFloatable)
        right_dock.setMaximumWidth(300)

        self.minimap = Minimap()
        self.minimap.setStyleSheet("""
            QPlainTextEdit {
                background-color: #1e1e1e;
                color: #569cd6;
                border: none;
                font-family: 'Consolas', monospace;
                font-size: 2px;
            }
        """)

        right_dock.setWidget(self.minimap)
        self.addDockWidget(Qt.RightDockWidgetArea, right_dock)

    def setup_bottom_dock(self):
        """Configura o dock inferior com múltiplas abas"""
        bottom_dock = QDockWidget("Output", self)
        bottom_dock.setFeatures(QDockWidget.DockWidgetMovable | QDockWidget.DockWidgetFloatable)

        self.output_tabs = QTabWidget()
        self.output_tabs.setTabPosition(QTabWidget.North)

        # Terminal
        self.setup_terminal_tab()

        # Output
        self.setup_output_tab()

        # Debug
        self.setup_debug_tab()

        # Errors
        self.setup_errors_tab()

        # Lint
        self.setup_lint_tab()

        bottom_dock.setWidget(self.output_tabs)
        self.addDockWidget(Qt.BottomDockWidgetArea, bottom_dock)

    def setup_terminal_tab(self):
        """Configura a aba do terminal"""
        self.terminal_text = TerminalTextEdit(self)
        self.terminal_text.setFont(QFont(self.current_font, 10))
        self.output_tabs.addTab(self.terminal_text, "💻 Terminal Output")  # D: Adicionar nome descritivo

    def setup_output_tab(self):
        """Configura a aba de output"""
        self.output_text = QPlainTextEdit()
        self.output_text.setReadOnly(True)
        self.output_text.setFont(QFont(self.current_font, 10))
        self.output_text.setStyleSheet("""
            QPlainTextEdit {
                background-color: #1e1e1e;
                color: #d4d4d4;
                border: none;
                font-family: 'Consolas', monospace;
            }
        """)
        self.output_tabs.addTab(self.output_text, "📤 Output Console")  # D: Adicionar nome descritivo

    def setup_debug_tab(self):
        """Configura a aba de debug"""
        self.debug_text = QPlainTextEdit()
        self.debug_text.setReadOnly(True)
        self.debug_text.setFont(QFont(self.current_font, 10))
        self.debug_text.setStyleSheet("""
            QPlainTextEdit {
                background-color: #1e1e1e;
                color: #ce9178;
                border: none;
                font-family: 'Consolas', monospace;
            }
        """)
        self.output_tabs.addTab(self.debug_text, "🐛 Debug Log")  # D: Adicionar nome descritivo

    def setup_errors_tab(self):
        """Configura a aba de erros"""
        self.errors_text = QPlainTextEdit()
        self.errors_text.setReadOnly(True)
        self.errors_text.setFont(QFont(self.current_font, 10))
        self.errors_text.setStyleSheet("""
            QPlainTextEdit {
                background-color: #1e1e1e;
                color: #f44747;
                border: none;
                font-family: 'Consolas', monospace;
            }
        """)
        self.output_tabs.addTab(self.errors_text, "❌ Error Log")  # D: Adicionar nome descritivo

    def setup_lint_tab(self):
        """Configura a aba de lint"""
        self.lint_text = QPlainTextEdit()
        self.lint_text.setReadOnly(True)
        self.lint_text.setFont(QFont(self.current_font, 10))
        self.lint_text.setStyleSheet("""
            QPlainTextEdit {
                background-color: #1e1e1e;
                color: #ffcc66;
                border: none;
                font-family: 'Consolas', monospace;
            }
        """)
        self.output_tabs.addTab(self.lint_text, "📋 Lint Report")  # D: Adicionar nome descritivo

    def setup_menu(self):
        """Configura o menu principal otimizado"""
        menubar = self.menuBar()

        # Menu Arquivo
        file_menu = menubar.addMenu("📁 Arquivo")
        self.setup_file_menu(file_menu)

        # Menu Editar
        edit_menu = menubar.addMenu("✏️ Editar")
        self.setup_edit_menu(edit_menu)

        # Menu Visualizar
        view_menu = menubar.addMenu("👁️ Visualizar")
        self.setup_view_menu(view_menu)

        # Menu Executar
        run_menu = menubar.addMenu("🚀 Executar")
        self.setup_run_menu(run_menu)

        # Menu Projeto
        project_menu = menubar.addMenu("📦 Projeto")
        self.setup_project_menu(project_menu)

        # Menu Ferramentas
        tools_menu = menubar.addMenu("🛠️ Ferramentas")
        self.setup_tools_menu(tools_menu)

        # Menu Ajuda
        help_menu = menubar.addMenu("❓ Ajuda")
        self.setup_help_menu(help_menu)

    def setup_file_menu(self, menu):
        """Configura o menu Arquivo"""
        actions = [
            ("📄 Novo Arquivo", "Ctrl+N", self.new_file),
            ("📁 Novo Projeto", "Ctrl+Shift+N", self.create_project),
            ("📂 Abrir Arquivo", "Ctrl+O", self.open_file),
            ("📂 Abrir Projeto", "Ctrl+Shift+O", self.set_project),
            ("💾 Salvar", "Ctrl+S", self.save_file),
            ("💾 Salvar Como", "Ctrl+Shift+S", self.save_file_as),
            ("🔒 Salvar Tudo", "Ctrl+Alt+S", self.save_all_files),
            ("---", None, None),
            ("🚪 Sair", "Ctrl+Q", self.close)
        ]

        self.create_menu_actions(menu, actions)

    def setup_edit_menu(self, menu):
        """Configura o menu Editar"""
        actions = [
            ("↶ Desfazer", "Ctrl+Z",
             lambda: self.get_current_editor()[0].undo() if self.get_current_editor()[0] else None),
            ("↷ Refazer", "Ctrl+Y",
             lambda: self.get_current_editor()[0].redo() if self.get_current_editor()[0] else None),
            ("---", None, None),
            ("✂️ Recortar", "Ctrl+X",
             lambda: self.get_current_editor()[0].cut() if self.get_current_editor()[0] else None),
            ("📋 Copiar", "Ctrl+C",
             lambda: self.get_current_editor()[0].copy() if self.get_current_editor()[0] else None),
            ("📝 Colar", "Ctrl+V",
             lambda: self.get_current_editor()[0].paste() if self.get_current_editor()[0] else None),
            ("---", None, None),
            ("🔍 Buscar", "Ctrl+F", self.show_find_dialog),
            ("🔄 Substituir", "Ctrl+H", self.show_replace_dialog),
            ("---", None, None),
            ("🎯 Auto-completar", "Ctrl+Space", self.force_auto_complete_current),
            ("📐 Corrigir Indentação", "Ctrl+I", self.fix_indentation_current)
        ]

        self.create_menu_actions(menu, actions)

    def setup_view_menu(self, menu):
        """Configura o menu Visualizar"""
        actions = [
            ("📊 Layout Dividido", "Ctrl+\\", self.split_view),
            ("🔍 Zoom In", "Ctrl+=", self.zoom_in),
            ("🔍 Zoom Out", "Ctrl+-", self.zoom_out),
            ("🔍 Zoom Reset", "Ctrl+0", self.zoom_reset),
            ("---", None, None),
            ("👁️ Mostrar/Ocultar Explorer", "Ctrl+Shift+E", self.toggle_explorer),
            ("👁️ Mostrar/Ocultar Terminal", "Ctrl+`", self.toggle_terminal),
            ("👁️ Mostrar/Ocultar Minimap", "Ctrl+Shift+M", self.toggle_minimap),
            ("---", None, None),
            ("🎨 Tema Escuro", None, lambda: self.set_dark_theme_optimized()),
            ("🎨 Tema Claro", None, lambda: self.set_light_theme()),
            ("🔤 Fonte...", None, self.show_font_dialog)
        ]

        self.create_menu_actions(menu, actions)

    def setup_run_menu(self, menu):
        """Configura o menu Executar"""
        actions = [
            ("▶️ Executar", "F5", self.run_code),
            ("🐛 Debug", "F6", self.debug_code),
            ("⏸️ Pausar", "F7", self.pause_execution),
            ("⏹️ Parar", "F8", self.stop_execution),
            ("---", None, None),
            ("🧪 Executar Testes", "Ctrl+T", self.run_tests),
            ("📊 Coverage", "Ctrl+Shift+T", self.run_coverage)
        ]

        self.create_menu_actions(menu, actions)

    def setup_project_menu(self, menu):
        """Configura o menu Projeto"""
        actions = [
            ("📦 Novo Projeto", None, self.create_project),
            ("📂 Abrir Projeto", None, self.set_project),
            ("🔧 Configurar Projeto", None, self.configure_project),
            ("---", None, None),
            ("🐍 Criar Virtualenv", None, self.create_venv),
            ("📚 Instalar Dependências", None, self.install_dependencies),
            ("---", None, None),
            ("📦 Empacotar", None, self.package_project),
            ("🚀 Deploy", None, self.deploy_project)
        ]

        self.create_menu_actions(menu, actions)

    def setup_tools_menu(self, menu):
        """Configura o menu Ferramentas"""
        actions = [
            ("🔧 Gerenciar Pacotes", None, self.manage_packages),
            ("🐍 Selecionar Python", None, self.select_python_version),
            ("🔍 Linter", None, self.run_linter),
            ("📐 Formatar Código", "Ctrl+Shift+F", self.format_code),
            ("---", None, None),
            ("⚙️ Configurações", "Ctrl+,", self.show_settings)
        ]

        self.create_menu_actions(menu, actions)

    def setup_help_menu(self, menu):
        """Configura o menu Ajuda"""
        actions = [
            ("📚 Documentação", "F1", self.show_documentation),
            ("🐛 Reportar Bug", None, self.report_bug),
            ("💡 Sugerir Feature", None, self.suggest_feature),
            ("---", None, None),
            ("ℹ️ Sobre", None, self.show_about)
        ]

        self.create_menu_actions(menu, actions)

    def create_menu_actions(self, menu, actions):
        """Cria ações de menu a partir de uma lista"""
        for text, shortcut, callback in actions:
            if text == "---":
                menu.addSeparator()
            else:
                action = QAction(text, self)
                if shortcut:
                    action.setShortcut(shortcut)
                if callback:
                    action.triggered.connect(callback)
                menu.addAction(action)

    def setup_toolbar(self):
        """Configura a toolbar principal"""
        toolbar = QToolBar("Ferramentas Principais")
        toolbar.setIconSize(QSize(20, 20))
        toolbar.setMovable(True)
        toolbar.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)  # B: Mostrar ícone + texto

        # Ações da toolbar
        actions = [
            ("📄 Novo Arquivo", "Novo Arquivo", "Ctrl+N", self.new_file),
            ("📂 Abrir Arquivo", "Abrir Arquivo", "Ctrl+O", self.open_file),
            ("💾 Salvar", "Salvar", "Ctrl+S", self.save_file),
            ("---", None, None, None),
            ("↶ Desfazer", "Desfazer", "Ctrl+Z",
             lambda: self.get_current_editor()[0].undo() if self.get_current_editor()[0] else None),
            ("↷ Refazer", "Refazer", "Ctrl+Y",
             lambda: self.get_current_editor()[0].redo() if self.get_current_editor()[0] else None),
            ("---", None, None, None),
            ("▶️ Executar", "Executar", "F5", self.run_code),
            ("🐛 Debug", "Debug", "F6", self.debug_code),
            ("---", None, None, None),
            ("🔍 Buscar", "Buscar", "Ctrl+F", self.show_find_dialog),
            ("🎯 Auto-completar", "Auto-completar", "Ctrl+Space", self.force_auto_complete_current)
        ]

        for icon, text, shortcut, callback in actions:  # B: Usar 'text' para setText
            if icon == "---":
                toolbar.addSeparator()
            else:
                action = QAction(icon, self)
                action.setText(text)  # B: Adicionar nome ao lado do ícone
                action.setToolTip(text)  # Manter tooltip
                if shortcut:
                    action.setShortcut(shortcut)
                if callback:
                    action.triggered.connect(callback)
                toolbar.addAction(action)

        self.addToolBar(toolbar)

    def setup_statusbar(self):
        """Configura a barra de status otimizada - CORRIGIDO"""
        status_bar = self.statusBar()

        # Informações do arquivo
        self.file_info_label = QLabel("Sem arquivo")
        status_bar.addWidget(self.file_info_label)

        # Informações do cursor
        self.cursor_info_label = QLabel("Linha: 1, Coluna: 1")
        status_bar.addPermanentWidget(self.cursor_info_label)

        # Informações do projeto
        self.project_info_label = QLabel("Sem projeto")
        status_bar.addPermanentWidget(self.project_info_label)

        # Progresso - CORREÇÃO: Criar instância corretamente
        self.status_progress = StatusBarProgress()
        status_bar.addPermanentWidget(self.status_progress)

    def setup_connections(self):
        """Configura as conexões de sinais"""
        # Conexões do explorador de arquivos
        self.file_tree.doubleClicked.connect(self.open_from_tree)
        self.file_tree.setContextMenuPolicy(Qt.CustomContextMenu)
        self.file_tree.customContextMenuRequested.connect(self.show_explorer_context_menu)

        # Conexões dos problemas
        self.problems_list.itemClicked.connect(self.jump_to_error)

        # Conexões das abas
        self.tab_widget.tabCloseRequested.connect(self.close_tab)
        self.tab_widget.currentChanged.connect(self.on_tab_changed)

        # Conexões dos botões
        self.refresh_explorer_btn.triggered.connect(self.refresh_explorer)
        self.new_file_btn.triggered.connect(self.create_new_file_in_explorer)
        self.new_folder_btn.triggered.connect(self.create_new_folder_in_explorer)
        self.clear_problems_btn.triggered.connect(self.clear_problems)
        self.run_lint_btn.triggered.connect(self.run_linter)

        # Conexões do terminal
        self.shell_process.readyReadStandardOutput.connect(self.handle_terminal_output)
        self.shell_process.readyReadStandardError.connect(self.handle_terminal_error)

    def setup_shortcuts(self):
        """Configura atalhos de teclado globais"""
        # Navegação entre abas
        QShortcut("Ctrl+Tab", self).activated.connect(self.next_tab)
        QShortcut("Ctrl+Shift+Tab", self).activated.connect(self.previous_tab)

        # Navegação entre splits
        QShortcut("Ctrl+1", self).activated.connect(lambda: self.focus_split(0))
        QShortcut("Ctrl+2", self).activated.connect(lambda: self.focus_split(1))

        # Comandos rápidos
        QShortcut("Ctrl+P", self).activated.connect(self.show_command_palette)

    def set_dark_theme_optimized(self):
        """Tema escuro otimizado para programação"""
        palette = QPalette()

        # Cores base
        dark_bg = QColor(30, 30, 30)
        darker_bg = QColor(20, 20, 20)
        light_text = QColor(220, 220, 220)
        highlight = QColor(86, 156, 214)
        highlight_text = QColor(255, 255, 255)

        # Configuração da paleta
        palette.setColor(QPalette.Window, dark_bg)
        palette.setColor(QPalette.WindowText, light_text)
        palette.setColor(QPalette.Base, darker_bg)
        palette.setColor(QPalette.AlternateBase, dark_bg)
        palette.setColor(QPalette.ToolTipBase, dark_bg)
        palette.setColor(QPalette.ToolTipText, light_text)
        palette.setColor(QPalette.Text, light_text)
        palette.setColor(QPalette.Button, dark_bg)
        palette.setColor(QPalette.ButtonText, light_text)
        palette.setColor(QPalette.BrightText, QColor(255, 0, 0))
        palette.setColor(QPalette.Link, highlight)
        palette.setColor(QPalette.Highlight, highlight)
        palette.setColor(QPalette.HighlightedText, highlight_text)

        # Cores para estados desabilitados
        palette.setColor(QPalette.Disabled, QPalette.Text, QColor(127, 127, 127))
        palette.setColor(QPalette.Disabled, QPalette.ButtonText, QColor(127, 127, 127))

        QApplication.setPalette(palette)
        QApplication.setStyle("Fusion")

        # CSS adicional para componentes específicos (C: Nivelar título do Minimap com padding/align)
        self.setStyleSheet("""
            QMainWindow {
                background-color: #1e1e1e;
            }
            QMenuBar {
                background-color: #2d2d30;
                color: #cccccc;
                border: none;
            }
            QMenuBar::item:selected {
                background-color: #3e3e42;
            }
            QMenu {
                background-color: #2d2d30;
                color: #cccccc;
                border: 1px solid #3e3e42;
            }
            QMenu::item:selected {
                background-color: #3e3e42;
            }
            QToolBar {
                background-color: #2d2d30;
                border: none;
                spacing: 3px;
            }
            QToolButton {
                background-color: transparent;
                border: 1px solid transparent;
                border-radius: 3px;
                padding: 4px;
            }
            QToolButton:hover {
                background-color: #3e3e42;
                border: 1px solid #505050;
            }
            QStatusBar {
                background-color: #007acc;
                color: white;
            }
            QDockWidget {
                titlebar-close-icon: url(close.png);
                titlebar-normal-icon: url(float.png);
            }
            QDockWidget::title {
                background-color: #2d2d30;
                padding: 4px 8px;  /* C: Ajuste de padding para nivelar títulos */
                text-align: left;  /* C: Alinhar à esquerda para consistência */
                font-weight: bold;
            }
        """)

    # ===== MÉTODOS PRINCIPAIS OTIMIZADOS =====

    def new_file(self):
        """Cria um novo arquivo"""
        tab = EditorTab(file_path=None, parent=self.tab_widget)
        index = self.tab_widget.addTab(tab, "📄 novo_arquivo.py")
        self.tab_widget.setCurrentIndex(index)

        # Foca no editor
        tab.editor.setFocus()

    def open_file(self, file_path=None):
        """Abre um arquivo de forma otimizada"""
        if not file_path:
            file_path, _ = QFileDialog.getOpenFileName(
                self,
                "Abrir Arquivo",
                self.project_path or QDir.homePath(),
                "Arquivos de Código (*.py *.js *.html *.css *.json *.xml *.txt);;Todos os Arquivos (*.*)"
            )

        if file_path:
            # Verifica se o arquivo já está aberto
            for i in range(self.tab_widget.count()):
                tab = self.tab_widget.widget(i)
                if hasattr(tab, 'file_path') and tab.file_path == file_path:
                    self.tab_widget.setCurrentIndex(i)
                    return

            # Cria nova aba
            try:
                tab = EditorTab(file_path=file_path, parent=self.tab_widget)
                index = self.tab_widget.addTab(tab, os.path.basename(file_path))
                self.tab_widget.setCurrentIndex(index)

                # Atualiza informações
                self.update_file_info(file_path)

            except Exception as e:
                QMessageBox.warning(self, "Erro", f"Não foi possível abrir o arquivo:\n{str(e)}")

    def save_file(self):
        """Salva o arquivo atual"""
        editor, file_path = self.get_current_editor()
        if not editor:
            return

        if file_path:
            try:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(editor.toPlainText())

                # Atualiza timestamp no explorador
                self.refresh_explorer()

                # Mostra confirmação
                self.statusBar().showMessage(f"✅ Arquivo salvo: {os.path.basename(file_path)}", 3000)

            except Exception as e:
                QMessageBox.warning(self, "Erro", f"Não foi possível salvar o arquivo:\n{str(e)}")
        else:
            self.save_file_as()

    def save_file_as(self):
        """Salva o arquivo atual com novo nome"""
        editor, file_path = self.get_current_editor()
        if not editor:
            return

        new_path, _ = QFileDialog.getSaveFileName(
            self,
            "Salvar Como",
            self.project_path or QDir.homePath(),
            "Arquivos Python (*.py);;Todos os Arquivos (*.*)"
        )

        if new_path:
            try:
                with open(new_path, 'w', encoding='utf-8') as f:
                    f.write(editor.toPlainText())

                # Atualiza a aba
                current_tab = self.tab_widget.currentWidget()
                if hasattr(current_tab, 'file_path'):
                    current_tab.file_path = new_path
                    index = self.tab_widget.currentIndex()
                    self.tab_widget.setTabText(index, os.path.basename(new_path))

                self.update_file_info(new_path)
                self.statusBar().showMessage(f"✅ Arquivo salvo como: {os.path.basename(new_path)}", 3000)

            except Exception as e:
                QMessageBox.warning(self, "Erro", f"Não foi possível salvar o arquivo:\n{str(e)}")

    def save_all_files(self):
        """Salva todos os arquivos abertos"""
        for i in range(self.tab_widget.count()):
            self.tab_widget.setCurrentIndex(i)
            self.save_file()

    def run_code(self):
        """Executa o código atual de forma otimizada"""
        editor, file_path = self.get_current_editor()
        if not file_path:
            QMessageBox.information(self, "Informação", "Nenhum arquivo para executar.")
            return

        if not file_path.endswith('.py'):
            QMessageBox.information(self, "Informação", "Apenas arquivos Python podem ser executados.")
            return

        try:
            # Limpa output anterior
            self.output_text.clear()

            # Mostra que está executando
            self.output_tabs.setCurrentWidget(self.output_text)
            self.output_text.appendPlainText(f"🚀 Executando: {os.path.basename(file_path)}\n{'-' * 50}")

            # Executa o código
            python_exec = self.get_python_executable()
            result = subprocess.run(
                [python_exec, file_path],
                capture_output=True,
                text=True,
                timeout=30,
                cwd=self.project_path or os.path.dirname(file_path),
                encoding='utf-8'
            )

            # Mostra resultados
            if result.stdout:
                self.output_text.appendPlainText("📤 SAÍDA:")
                self.output_text.appendPlainText(result.stdout)

            if result.stderr:
                self.output_text.appendPlainText("❌ ERROS:")
                self.output_text.appendPlainText(result.stderr)

            if result.returncode == 0:
                self.output_text.appendPlainText(f"\n✅ Execução concluída com sucesso!")
            else:
                self.output_text.appendPlainText(f"\n❌ Execução falhou (código: {result.returncode})")

        except subprocess.TimeoutExpired:
            self.output_text.appendPlainText("⏰ Timeout: A execução demorou muito.")
        except Exception as e:
            self.output_text.appendPlainText(f"💥 Erro na execução: {str(e)}")

    def debug_code(self):
        """Executa o código em modo debug"""
        editor, file_path = self.get_current_editor()
        if not file_path:
            return

        try:
            self.debug_text.clear()
            self.output_tabs.setCurrentWidget(self.debug_text)

            python_exec = self.get_python_executable()
            result = subprocess.run(
                [python_exec, "-m", "pdb", file_path],
                capture_output=True,
                text=True,
                cwd=self.project_path or os.path.dirname(file_path),
                encoding='utf-8'
            )

            self.debug_text.setPlainText(result.stdout + result.stderr)

        except Exception as e:
            self.debug_text.setPlainText(f"Erro no debug: {str(e)}")

    def get_current_editor(self):
        """Obtém o editor atual de forma segura"""
        current_tab = self.tab_widget.currentWidget()
        if current_tab and hasattr(current_tab, 'editor'):
            return current_tab.editor, getattr(current_tab, 'file_path', None)
        return None, None

    def close_tab(self, index):
        """Fecha uma aba com confirmação se necessário"""
        tab = self.tab_widget.widget(index)

        # Verifica se há mudanças não salvas
        if hasattr(tab, 'editor') and hasattr(tab, 'file_path'):
            editor = tab.editor
            if tab.file_path:
                try:
                    with open(tab.file_path, 'r', encoding='utf-8') as f:
                        original_content = f.read()

                    if editor.toPlainText() != original_content:
                        reply = QMessageBox.question(
                            self,
                            "Salvar Alterações",
                            f"Deseja salvar as alterações em {os.path.basename(tab.file_path)}?",
                            QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel
                        )

                        if reply == QMessageBox.Yes:
                            self.save_file()
                        elif reply == QMessageBox.Cancel:
                            return
                except:
                    pass

        self.tab_widget.removeTab(index)

    def on_tab_changed(self, index):
        """Atualiza a interface quando a aba muda"""
        if index >= 0:
            tab = self.tab_widget.widget(index)
            if hasattr(tab, 'file_path') and tab.file_path:
                self.update_file_info(tab.file_path)

                # Atualiza minimap
                if hasattr(tab, 'editor'):
                    self.minimap.setPlainText(tab.editor.toPlainText())
            else:
                self.update_file_info(None)

    def update_file_info(self, file_path):
        """Atualiza informações do arquivo na statusbar"""
        if file_path and os.path.exists(file_path):
            size = os.path.getsize(file_path)
            size_str = f"{size} bytes" if size < 1024 else f"{size / 1024:.1f} KB"
            self.file_info_label.setText(f"📄 {os.path.basename(file_path)} ({size_str})")
        else:
            self.file_info_label.setText("📄 Sem arquivo")

    def update_cursor_info(self, line, column):
        """Atualiza informações do cursor"""
        self.cursor_info_label.setText(f"📏 Linha: {line}, Coluna: {column}")

    def refresh_explorer(self):
        """Atualiza o explorador de arquivos"""
        if self.project_path:
            self.file_model.setRootPath(self.project_path)
            self.file_tree.setRootIndex(self.file_model.index(self.project_path))
        else:
            self.file_model.setRootPath(QDir.homePath())
            self.file_tree.setRootIndex(self.file_model.index(QDir.homePath()))

    def open_from_tree(self, index):
        """Abre arquivo a partir do explorador"""
        file_path = self.file_model.filePath(index)
        if os.path.isfile(file_path):
            self.open_file(file_path)

    def show_explorer_context_menu(self, position):
        """Mostra menu de contexto no explorador"""
        index = self.file_tree.indexAt(position)
        if not index.isValid():
            return

        menu = QMenu(self)

        file_path = self.file_model.filePath(index)
        is_file = os.path.isfile(file_path)

        if is_file:
            menu.addAction("📄 Abrir", lambda: self.open_file(file_path))
            menu.addAction("✏️ Renomear", lambda: self.rename_file(file_path))
            menu.addAction("🗑️ Excluir", lambda: self.delete_file(file_path))
            menu.addSeparator()
            menu.addAction("📋 Copiar Caminho", lambda: self.copy_file_path(file_path))
        else:
            menu.addAction("📄 Novo Arquivo", lambda: self.create_new_file_in_folder(file_path))
            menu.addAction("📁 Nova Pasta", lambda: self.create_new_folder_in_folder(file_path))
            menu.addAction("✏️ Renomear", lambda: self.rename_file(file_path))
            menu.addAction("🗑️ Excluir", lambda: self.delete_file(file_path))

        menu.exec_(self.file_tree.viewport().mapToGlobal(position))

    def create_new_file_in_explorer(self):
        """Cria novo arquivo no explorador"""
        current_index = self.file_tree.currentIndex()
        if current_index.isValid():
            parent_path = self.file_model.filePath(current_index)
            if not os.path.isdir(parent_path):
                parent_path = os.path.dirname(parent_path)
        else:
            parent_path = self.project_path or QDir.homePath()

        self.create_new_file_in_folder(parent_path)

    def create_new_folder_in_explorer(self):
        """Cria nova pasta no explorador"""
        current_index = self.file_tree.currentIndex()
        if current_index.isValid():
            parent_path = self.file_model.filePath(current_index)
            if not os.path.isdir(parent_path):
                parent_path = os.path.dirname(parent_path)
        else:
            parent_path = self.project_path or QDir.homePath()

        self.create_new_folder_in_folder(parent_path)

    def create_new_file_in_folder(self, folder_path):
        """Cria novo arquivo com diálogo intuitivo"""
        dialog = NewFileDialog(self)
        if dialog.exec() == QDialog.Accepted:
            file_name = dialog.get_file_name()
            if file_name:
                file_path = os.path.join(folder_path, file_name)
                try:
                    with open(file_path, 'w', encoding='utf-8') as f:
                        # Template básico baseado na extensão
                        ext = os.path.splitext(file_name)[1]
                        if ext == '.py':
                            f.write(
                                '# Novo script Python\n\ndef main():\n    pass\n\nif __name__ == "__main__":\n    main()\n')
                        elif ext == '.js':
                            f.write('// Novo script JavaScript\nconsole.log("Hello World!");\n')
                        elif ext == '.html':
                            f.write(
                                '<!DOCTYPE html>\n<html><head><title>Novo</title></head><body><h1>Hello</h1></body></html>\n')
                        else:
                            f.write('# Novo arquivo\n')  # Default
                    self.refresh_explorer()
                    self.open_file(file_path)  # Abre automaticamente
                    self.statusBar().showMessage(f"✅ Arquivo criado: {file_name}", 2000)
                except Exception as e:
                    QMessageBox.warning(self, "Erro", f"Não foi possível criar o arquivo:\n{str(e)}")
            else:
                QMessageBox.warning(self, "Erro", "Nome do arquivo inválido.")

    def create_new_folder_in_folder(self, folder_path):
        """Cria nova pasta em uma pasta específica"""
        folder_name, ok = QInputDialog.getText(
            self,
            "Nova Pasta",
            "Nome da pasta:",
            text="nova_pasta"
        )

        if ok and folder_name:
            new_folder_path = os.path.join(folder_path, folder_name)
            try:
                os.makedirs(new_folder_path, exist_ok=True)
                self.refresh_explorer()
            except Exception as e:
                QMessageBox.warning(self, "Erro", f"Não foi possível criar a pasta:\n{str(e)}")

    def rename_file(self, file_path):
        """Renomeia arquivo ou pasta"""
        current_name = os.path.basename(file_path)
        new_name, ok = QInputDialog.getText(
            self,
            "Renomear",
            f"Novo nome para '{current_name}':",
            text=current_name
        )

        if ok and new_name and new_name != current_name:
            new_path = os.path.join(os.path.dirname(file_path), new_name)
            try:
                os.rename(file_path, new_path)
                self.refresh_explorer()

                # Atualiza aba se o arquivo estava aberto
                for i in range(self.tab_widget.count()):
                    tab = self.tab_widget.widget(i)
                    if hasattr(tab, 'file_path') and tab.file_path == file_path:
                        tab.file_path = new_path
                        self.tab_widget.setTabText(i, new_name)
                        break

            except Exception as e:
                QMessageBox.warning(self, "Erro", f"Não foi possível renomear:\n{str(e)}")

    def delete_file(self, file_path):
        """Exclui arquivo ou pasta"""
        name = os.path.basename(file_path)
        is_file = os.path.isfile(file_path)

        reply = QMessageBox.question(
            self,
            "Confirmar Exclusão",
            f"Tem certeza que deseja excluir {'o arquivo' if is_file else 'a pasta'} '{name}'?",
            QMessageBox.Yes | QMessageBox.No
        )

        if reply == QMessageBox.Yes:
            try:
                if is_file:
                    os.remove(file_path)
                    # Fecha aba se o arquivo estava aberto
                    for i in range(self.tab_widget.count()):
                        tab = self.tab_widget.widget(i)
                        if hasattr(tab, 'file_path') and tab.file_path == file_path:
                            self.tab_widget.removeTab(i)
                            break
                else:
                    shutil.rmtree(file_path)

                self.refresh_explorer()

            except Exception as e:
                QMessageBox.warning(self, "Erro", f"Não foi possível excluir:\n{str(e)}")

    def copy_file_path(self, file_path):
        """Copia o caminho do arquivo para a área de transferência"""
        clipboard = QGuiApplication.clipboard()
        clipboard.setText(file_path)
        self.statusBar().showMessage(f"📋 Caminho copiado: {file_path}", 2000)

    def jump_to_error(self, item):
        """Salta para a linha do erro na lista de problemas"""
        data = item.data(Qt.UserRole)
        if data:
            file_path = data.get('file')
            line_str = data.get('line', '1')

            try:
                line_num = int(line_str) - 1
            except:
                line_num = 0

            # Encontra ou abre o arquivo
            tab_index = -1
            for i in range(self.tab_widget.count()):
                tab = self.tab_widget.widget(i)
                if hasattr(tab, 'file_path') and tab.file_path == file_path:
                    tab_index = i
                    break

            if tab_index == -1 and os.path.exists(file_path):
                self.open_file(file_path)
                tab_index = self.tab_widget.currentIndex()

            if tab_index >= 0:
                self.tab_widget.setCurrentIndex(tab_index)
                tab = self.tab_widget.widget(tab_index)
                editor = tab.editor

                # Move cursor para a linha do erro
                cursor = editor.textCursor()
                cursor.movePosition(QTextCursor.Start)
                cursor.movePosition(QTextCursor.Down, QTextCursor.MoveAnchor, line_num)
                editor.setTextCursor(cursor)
                editor.setFocus()

    def clear_problems(self):
        """Limpa a lista de problemas"""
        self.problems_list.clear()
        self.lint_text.clear()

    def run_linter(self):
        """Executa o linter no arquivo atual"""
        editor, file_path = self.get_current_editor()
        if file_path and file_path.endswith('.py'):
            current_tab = self.tab_widget.currentWidget()
            if hasattr(current_tab, 'start_linting'):
                current_tab.start_linting()
        else:
            QMessageBox.information(self, "Informação", "Apenas arquivos Python podem ser analisados.")

    def handle_terminal_output(self):
        """Processa saída do terminal"""
        data = self.shell_process.readAllStandardOutput().data().decode('utf-8', errors='ignore')
        self.terminal_text.append_output(data)

    def handle_terminal_error(self):
        """Processa erro do terminal"""
        data = self.shell_process.readAllStandardError().data().decode('utf-8', errors='ignore')
        self.terminal_text.append_output(data)

    def start_shell(self):
        """Inicia o processo do shell"""
        try:
            self.shell_process = QProcess(self)
            self.shell_process.readyReadStandardOutput.connect(self.handle_terminal_output)
            self.shell_process.readyReadStandardError.connect(self.handle_terminal_error)

            if os.name == 'nt':  # Windows
                self.shell_process.start("cmd.exe")
            else:  # Linux/Mac
                self.shell_process.start("/bin/bash", ["-i"])

            if self.project_path:
                self.activate_project()

        except Exception as e:
            self.terminal_text.append_output(f"❌ Erro ao iniciar terminal: {str(e)}\n")

    def activate_project(self):
        """Ativa o projeto no terminal"""
        if self.project_path and self.shell_process.state() == QProcess.Running:
            cd_command = f"cd \"{self.project_path}\"\n"
            self.shell_process.write(cd_command.encode())

            if self.venv_path and os.path.exists(self.venv_path):
                activate_script = os.path.join(self.venv_path, "Scripts",
                                               "activate.bat") if os.name == 'nt' else os.path.join(self.venv_path,
                                                                                                    "bin", "activate")
                if os.path.exists(activate_script):
                    activate_command = f'call "{activate_script}"\n' if os.name == 'nt' else f'source "{activate_script}"\n'
                    self.shell_process.write(activate_command.encode())

    def get_python_executable(self):
        """Obtém o executável Python"""
        if self.venv_path and os.path.exists(self.venv_path):
            if os.name == 'nt':  # Windows
                return os.path.join(self.venv_path, "Scripts", "python.exe")
            else:  # Linux/Mac
                return os.path.join(self.venv_path, "bin", "python")
        return sys.executable

    def check_python_version(self):
        """Verifica e exibe a versão do Python"""
        try:
            result = subprocess.run([self.get_python_executable(), "--version"],
                                    capture_output=True, text=True)
            version = result.stdout.strip()
            self.statusBar().showMessage(f"🐍 {version}", 5000)
        except:
            self.statusBar().showMessage("❌ Não foi possível detectar Python", 5000)

    # ===== MÉTODOS DE PROJETO =====

    def create_project(self):
        """Cria um novo projeto"""
        project_path = QFileDialog.getExistingDirectory(
            self,
            "Selecionar Pasta para o Projeto",
            QDir.homePath()
        )

        if project_path:
            project_name = os.path.basename(project_path)

            # Cria estrutura básica
            try:
                # Arquivo principal
                main_file = os.path.join(project_path, "main.py")
                with open(main_file, 'w', encoding='utf-8') as f:
                    f.write('''# Projeto: {project_name}

def main():
    """Função principal"""
    print("Hello World!")

if __name__ == "__main__":
    main()
'''.format(project_name=project_name))

                # README
                readme_file = os.path.join(project_path, "README.md")
                with open(readme_file, 'w', encoding='utf-8') as f:
                    f.write(f"# {project_name}\n\nProjeto criado com Py Dragon Studio IDE\n")

                # Requirements vazio
                req_file = os.path.join(project_path, "requirements.txt")
                with open(req_file, 'w', encoding='utf-8') as f:
                    f.write("# Dependências do projeto\n")

                self.set_project(project_path)
                self.open_file(main_file)

                QMessageBox.information(self, "Sucesso", f"Projeto '{project_name}' criado com sucesso!")

            except Exception as e:
                QMessageBox.warning(self, "Erro", f"Não foi possível criar o projeto:\n{str(e)}")

    def set_project(self, project_path=None):
        """Define o projeto atual"""
        if not project_path:
            project_path = QFileDialog.getExistingDirectory(
                self,
                "Selecionar Projeto",
                self.project_path or QDir.homePath()
            )

        if project_path:
            self.project_path = project_path
            self.project_info_label.setText(f"📦 {os.path.basename(project_path)}")

            # Atualiza explorador
            self.refresh_explorer()

            # Ativa no terminal
            self.activate_project()

            # Preload de módulos com progresso
            # self.preload_project_modules()

            self.statusBar().showMessage(f"✅ Projeto carregado: {project_path}", 3000)

    def preload_project_modules(self):
        """Pré-carrega módulos do projeto com feedback"""
        if not self.project_path:
            return

        def update_progress(value, message="", current=0, total=0):
            self.status_progress.update_progress(value, message)

        def update_status(message):
            self.status_progress.show_loading(message)

        # Configura callbacks de progresso
        module_cache_manager.set_progress_callbacks(update_progress, update_status)

        # Inicia preload em thread separada para não travar a UI
        import threading

        def preload_thread():
            try:
                module_cache_manager.preload_all_project_modules(self.project_path)
                self.status_progress.show_success("Módulos carregados!")
            except Exception as e:
                self.status_progress.show_error(f"Erro: {str(e)}")

        thread = threading.Thread(target=preload_thread, daemon=True)
        thread.start()

    def configure_project(self):
        """Configura o projeto"""
        if not self.project_path:
            QMessageBox.information(self, "Informação", "Nenhum projeto aberto.")
            return

        # Diálogo simples de configuração
        dialog = QDialog(self)
        dialog.setWindowTitle("Configurar Projeto")
        dialog.setFixedSize(400, 300)

        layout = QVBoxLayout()

        # Configurações básicas
        layout.addWidget(QLabel(f"Projeto: {os.path.basename(self.project_path)}"))

        # Virtualenv
        venv_layout = QHBoxLayout()
        venv_layout.addWidget(QLabel("Virtualenv:"))
        venv_label = QLabel(self.venv_path or "Não configurado")
        venv_layout.addWidget(venv_label)
        venv_btn = QPushButton("Selecionar")
        venv_btn.clicked.connect(lambda: self.select_venv(venv_label))
        venv_layout.addWidget(venv_btn)
        layout.addLayout(venv_layout)

        # Python
        python_layout = QHBoxLayout()
        python_layout.addWidget(QLabel("Python:"))
        python_label = QLabel(self.python_path)
        python_layout.addWidget(python_label)
        layout.addLayout(python_layout)

        # Botões
        btn_layout = QHBoxLayout()
        ok_btn = QPushButton("OK")
        ok_btn.clicked.connect(dialog.accept)
        cancel_btn = QPushButton("Cancelar")
        cancel_btn.clicked.connect(dialog.reject)

        btn_layout.addWidget(ok_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addLayout(btn_layout)

        dialog.setLayout(layout)
        dialog.exec_()

    def select_venv(self, label):
        """Seleciona virtualenv"""
        venv_path = QFileDialog.getExistingDirectory(
            self,
            "Selecionar Virtualenv",
            self.project_path or QDir.homePath()
        )

        if venv_path:
            self.venv_path = venv_path
            label.setText(os.path.basename(venv_path))
            self.activate_project()

    def create_venv(self):
        """Cria virtualenv para o projeto"""
        if not self.project_path:
            QMessageBox.information(self, "Informação", "Nenhum projeto aberto.")
            return

        venv_name = "venv"
        venv_path = os.path.join(self.project_path, venv_name)

        try:
            # Usa o Python atual para criar o venv
            subprocess.run([sys.executable, "-m", "venv", venv_path], check=True)
            self.venv_path = venv_path
            self.activate_project()
            QMessageBox.information(self, "Sucesso", f"Virtualenv criado em: {venv_path}")
        except Exception as e:
            QMessageBox.warning(self, "Erro", f"Não foi criar o virtualenv:\n{str(e)}")

    def install_dependencies(self):
        """Instala dependências do projeto"""
        if not self.project_path:
            return

        requirements_file = os.path.join(self.project_path, "requirements.txt")
        if not os.path.exists(requirements_file):
            QMessageBox.information(self, "Informação", "Arquivo requirements.txt não encontrado.")
            return

        try:
            python_exec = self.get_python_executable()
            result = subprocess.run(
                [python_exec, "-m", "pip", "install", "-r", requirements_file],
                capture_output=True,
                text=True,
                cwd=self.project_path
            )

            self.output_tabs.setCurrentWidget(self.output_text)
            self.output_text.clear()
            self.output_text.appendPlainText("📦 Instalando dependências...\n")

            if result.stdout:
                self.output_text.appendPlainText(result.stdout)
            if result.stderr:
                self.output_text.appendPlainText(result.stderr)

            if result.returncode == 0:
                self.output_text.appendPlainText("\n✅ Dependências instaladas com sucesso!")
            else:
                self.output_text.appendPlainText(f"\n❌ Falha na instalação (código: {result.returncode})")

        except Exception as e:
            self.output_text.appendPlainText(f"💥 Erro: {str(e)}")

    def package_project(self):
        """Empacota o projeto"""
        if not self.project_path:
            QMessageBox.information(self, "Informação", "Nenhum projeto aberto.")
            return

        # Encontra arquivo principal
        main_files = [
            os.path.join(self.project_path, "main.py"),
            os.path.join(self.project_path, "app.py"),
            os.path.join(self.project_path, f"{os.path.basename(self.project_path)}.py")
        ]

        main_file = None
        for file in main_files:
            if os.path.exists(file):
                main_file = os.path.basename(file)
                break

        if not main_file:
            # Lista arquivos Python para escolha
            py_files = [f for f in os.listdir(self.project_path) if f.endswith('.py')]
            if not py_files:
                QMessageBox.information(self, "Informação", "Nenhum arquivo Python encontrado.")
                return

            main_file, ok = QInputDialog.getItem(
                self,
                "Selecionar Arquivo Principal",
                "Arquivo Python principal:",
                py_files,
                0,
                False
            )

            if not ok:
                return

        dialog = PackageDialog(self, self.project_path, main_file)
        dialog.exec_()

    def deploy_project(self):
        """Faz deploy do projeto"""
        QMessageBox.information(self, "Informação", "Funcionalidade de deploy em desenvolvimento.")

    # ===== MÉTODOS DE FERRAMENTAS =====

    def manage_packages(self):
        """Gerencia pacotes Python"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Gerenciar Pacotes")
        dialog.setFixedSize(500, 400)

        layout = QVBoxLayout()

        # Lista de pacotes instalados
        layout.addWidget(QLabel("Pacotes Instalados:"))
        packages_list = QListWidget()
        layout.addWidget(packages_list)

        # Carrega pacotes
        try:
            python_exec = self.get_python_executable()
            result = subprocess.run(
                [python_exec, "-m", "pip", "list", "--format=json"],
                capture_output=True,
                text=True
            )

            if result.returncode == 0:
                packages = json.loads(result.stdout)
                for pkg in packages:
                    packages_list.addItem(f"{pkg['name']}=={pkg['version']}")
        except:
            pass

        # Botões de ação
        btn_layout = QHBoxLayout()
        install_btn = QPushButton("Instalar Pacote")
        install_btn.clicked.connect(lambda: self.install_package())
        uninstall_btn = QPushButton("Desinstalar")
        uninstall_btn.clicked.connect(lambda: self.uninstall_package(packages_list))

        btn_layout.addWidget(install_btn)
        btn_layout.addWidget(uninstall_btn)
        layout.addLayout(btn_layout)

        dialog.setLayout(layout)
        dialog.exec_()

    def install_package(self):
        """Instala um pacote"""
        package_name, ok = QInputDialog.getText(
            self,
            "Instalar Pacote",
            "Nome do pacote:"
        )

        if ok and package_name:
            try:
                python_exec = self.get_python_executable()
                result = subprocess.run(
                    [python_exec, "-m", "pip", "install", package_name],
                    capture_output=True,
                    text=True
                )

                if result.returncode == 0:
                    QMessageBox.information(self, "Sucesso", f"Pacote '{package_name}' instalado!")
                else:
                    QMessageBox.warning(self, "Erro", f"Falha na instalação:\n{result.stderr}")

            except Exception as e:
                QMessageBox.warning(self, "Erro", f"Erro na instalação:\n{str(e)}")

    def uninstall_package(self, packages_list):
        """Desinstala pacote selecionado"""
        current_item = packages_list.currentItem()
        if not current_item:
            return

        package_name = current_item.text().split('==')[0]

        reply = QMessageBox.question(
            self,
            "Confirmar",
            f"Desinstalar pacote '{package_name}'?"
        )

        if reply == QMessageBox.Yes:
            try:
                python_exec = self.get_python_executable()
                result = subprocess.run(
                    [python_exec, "-m", "pip", "uninstall", "-y", package_name],
                    capture_output=True,
                    text=True
                )

                if result.returncode == 0:
                    packages_list.takeItem(packages_list.currentRow())
                    QMessageBox.information(self, "Sucesso", f"Pacote '{package_name}' desinstalado!")
                else:
                    QMessageBox.warning(self, "Erro", f"Falha na desinstalação:\n{result.stderr}")

            except Exception as e:
                QMessageBox.warning(self, "Erro", f"Erro na desinstalação:\n{str(e)}")

    def select_python_version(self):
        """Seleciona versão do Python"""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Selecionar Executável Python",
            "/usr/bin" if os.name != 'nt' else "C:\\",
            "Executável Python (python python.exe)"
        )

        if file_path:
            self.python_path = file_path
            self.statusBar().showMessage(f"🐍 Python definido: {file_path}", 3000)

    def format_code(self):
        """Formata o código atual"""
        editor, file_path = self.get_current_editor()
        if not editor or not file_path or not file_path.endswith('.py'):
            QMessageBox.information(self, "Informação", "Apenas arquivos Python podem ser formatados.")
            return

        try:
            # Usa autopep8 se disponível
            python_exec = self.get_python_executable()

            # Salva o arquivo primeiro
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(editor.toPlainText())

            # Tenta formatar com autopep8
            result = subprocess.run(
                [python_exec, "-m", "autopep8", "--in-place", "--aggressive", file_path],
                capture_output=True,
                text=True
            )

            if result.returncode == 0:
                # Recarrega o arquivo formatado
                with open(file_path, 'r', encoding='utf-8') as f:
                    formatted_content = f.read()

                editor.setPlainText(formatted_content)
                self.statusBar().showMessage("✅ Código formatado com sucesso!", 3000)
            else:
                QMessageBox.warning(self, "Erro", "autopep8 não disponível. Instale com: pip install autopep8")

        except Exception as e:
            QMessageBox.warning(self, "Erro", f"Erro na formatação:\n{str(e)}")

    def show_settings(self):
        """Mostra configurações"""
        QMessageBox.information(self, "Configurações", "Painel de configurações em desenvolvimento.")

    # ===== MÉTODOS DE VISUALIZAÇÃO =====

    def split_view(self):
        """Divide a visualização"""
        current_tab = self.tab_widget.currentWidget()
        if not current_tab:
            return

        # Cria splitter se não existir
        if not isinstance(self.tab_widget.currentWidget(), QSplitter):
            editor = current_tab.editor
            file_path = current_tab.file_path

            splitter = QSplitter(Qt.Horizontal)

            # Primeiro editor
            tab1 = EditorTab(file_path=file_path, parent=splitter)
            tab1.editor.setPlainText(editor.toPlainText())

            # Segundo editor
            tab2 = EditorTab(file_path=file_path, parent=splitter)
            tab2.editor.setPlainText(editor.toPlainText())

            splitter.addWidget(tab1)
            splitter.addWidget(tab2)

            # Substitui a aba atual pelo splitter
            index = self.tab_widget.currentIndex()
            self.tab_widget.removeTab(index)
            self.tab_widget.insertTab(index, splitter,
                                      f"📊 {os.path.basename(file_path) if file_path else 'novo_arquivo.py'}")
            self.tab_widget.setCurrentIndex(index)

    def zoom_in(self):
        """Aumenta o zoom"""
        editor, _ = self.get_current_editor()
        if editor:
            font = editor.font()
            size = font.pointSize()
            font.setPointSize(min(size + 1, 24))
            editor.setFont(font)

    def zoom_out(self):
        """Diminui o zoom"""
        editor, _ = self.get_current_editor()
        if editor:
            font = editor.font()
            size = font.pointSize()
            font.setPointSize(max(size - 1, 8))
            editor.setFont(font)

    def zoom_reset(self):
        """Reseta o zoom"""
        editor, _ = self.get_current_editor()
        if editor:
            font = editor.font()
            font.setPointSize(12)
            editor.setFont(font)

    def toggle_explorer(self):
        """Alterna visibilidade do explorer"""
        for dock in self.findChildren(QDockWidget):
            if dock.windowTitle() == "Explorer":
                dock.setVisible(not dock.isVisible())
                break

    def toggle_terminal(self):
        """Alterna visibilidade do terminal"""
        for dock in self.findChildren(QDockWidget):
            if dock.windowTitle() == "Output":
                dock.setVisible(not dock.isVisible())
                break

    def toggle_minimap(self):
        """Alterna visibilidade do minimap"""
        for dock in self.findChildren(QDockWidget):
            if dock.windowTitle() == "Minimap":
                dock.setVisible(not dock.isVisible())
                break

    def show_font_dialog(self):
        """Mostra diálogo para selecionar fonte"""
        dialog = FontSelectionDialog(self)
        if dialog.exec_():
            new_font = dialog.get_selected_font()
            self.current_font = new_font

            # Aplica a fonte a todos os editores
            for i in range(self.tab_widget.count()):
                tab = self.tab_widget.widget(i)
                if hasattr(tab, 'editor'):
                    font = QFont(new_font, 12)
                    tab.editor.setFont(font)

    def set_light_theme(self):
        """Define tema claro"""
        palette = QPalette()
        palette.setColor(QPalette.Window, QColor(240, 240, 240))
        palette.setColor(QPalette.WindowText, QColor(0, 0, 0))
        palette.setColor(QPalette.Base, QColor(255, 255, 255))
        palette.setColor(QPalette.Text, QColor(0, 0, 0))
        QApplication.setPalette(palette)

    # ===== MÉTODOS DE AJUDA =====

    def show_documentation(self):
        """Mostra documentação"""
        QMessageBox.information(self, "Documentação",
                                "Py Dragon Studio IDE\n\n"
                                "Atalhos:\n"
                                "Ctrl+N - Novo arquivo\n"
                                "Ctrl+O - Abrir arquivo\n"
                                "Ctrl+S - Salvar\n"
                                "F5 - Executar\n"
                                "Ctrl+Space - Auto-completar\n\n"
                                "Recursos:\n"
                                "- Editor com syntax highlighting\n"
                                "- Terminal integrado\n"
                                "- Explorador de arquivos\n"
                                "- Linter Python\n"
                                "- Auto-completar inteligente")

    def report_bug(self):
        """Reporta bug"""
        QMessageBox.information(self, "Reportar Bug",
                                "Encontrou um bug?\n\n"
                                "Por favor, reporte em:\n"
                                "https://github.com/seu-usuario/py-dragon-studio/issues")

    def suggest_feature(self):
        """Sugere nova funcionalidade"""
        QMessageBox.information(self, "Sugerir Funcionalidade",
                                "Tem uma ideia para melhorar o IDE?\n\n"
                                "Envie sua sugestão em:\n"
                                "https://github.com/seu-usuario/py-dragon-studio/issues")

    def show_about(self):
        """Mostra informações sobre o aplicativo"""
        QMessageBox.about(self, "Sobre Py Dragon Studio IDE",
                          f"Py Dragon Studio IDE\n\n"
                          f"Versão: 1.0.0\n"
                          f"Python: {sys.version}\n"
                          f"Plataforma: {platform.system()}\n\n"
                          f"Um IDE Python moderno com foco em produtividade.\n\n"
                          f"Recursos:\n"
                          f"- Editor multi-linguagem\n"
                          f"- Terminal integrado\n"
                          f"- Auto-completar inteligente\n"
                          f"- Gerenciamento de projetos\n"
                          f"- Linter integrado")

    # ===== MÉTODOS DE NAVEGAÇÃO =====

    def next_tab(self):
        """Navega para a próxima aba"""
        current = self.tab_widget.currentIndex()
        next_index = (current + 1) % self.tab_widget.count()
        self.tab_widget.setCurrentIndex(next_index)

    def previous_tab(self):
        """Navega para a aba anterior"""
        current = self.tab_widget.currentIndex()
        previous_index = (current - 1) % self.tab_widget.count()
        self.tab_widget.setCurrentIndex(previous_index)

    def focus_split(self, index):
        """Foca em um split específico"""
        current_widget = self.tab_widget.currentWidget()
        if isinstance(current_widget, QSplitter):
            if index < current_widget.count():
                widget = current_widget.widget(index)
                if hasattr(widget, 'editor'):
                    widget.editor.setFocus()

    def show_command_palette(self):
        """Mostra palette de comandos"""
        commands = [
            "Novo Arquivo", "Abrir Arquivo", "Salvar", "Executar",
            "Debug", "Buscar", "Substituir", "Terminal", "Explorer"
        ]

        command, ok = QInputDialog.getItem(
            self,
            "Palette de Comandos",
            "Digite ou selecione um comando:",
            commands,
            0,
            True
        )

        if ok and command:
            if command == "Novo Arquivo":
                self.new_file()
            elif command == "Abrir Arquivo":
                self.open_file()
            elif command == "Salvar":
                self.save_file()
            elif command == "Executar":
                self.run_code()
            elif command == "Debug":
                self.debug_code()
            elif command == "Buscar":
                self.show_find_dialog()
            elif command == "Substituir":
                self.show_replace_dialog()
            elif command == "Terminal":
                self.toggle_terminal()
            elif command == "Explorer":
                self.toggle_explorer()

    # ===== MÉTODOS DE EDIÇÃO AVANÇADOS =====

    def show_find_dialog(self):
        """Mostra diálogo de busca"""
        editor, _ = self.get_current_editor()
        if not editor:
            return

        find_text, ok = QInputDialog.getText(
            self,
            "Buscar",
            "Texto para buscar:"
        )

        if ok and find_text:
            cursor = editor.textCursor()
            document = editor.document()

            # Busca a partir da posição atual
            cursor = document.find(find_text, cursor)
            if not cursor.isNull():
                editor.setTextCursor(cursor)
            else:
                QMessageBox.information(self, "Buscar", "Texto não encontrado.")

    def show_replace_dialog(self):
        """Mostra diálogo de substituir"""
        editor, _ = self.get_current_editor()
        if not editor:
            return

        find_text, ok1 = QInputDialog.getText(
            self,
            "Substituir",
            "Texto para buscar:"
        )

        if ok1 and find_text:
            replace_text, ok2 = QInputDialog.getText(
                self,
                "Substituir",
                "Substituir por:"
            )

            if ok2:
                text = editor.toPlainText()
                new_text = text.replace(find_text, replace_text)
                editor.setPlainText(new_text)

    def force_auto_complete_current(self):
        """Força auto-completar no editor atual"""
        editor, _ = self.get_current_editor()
        if editor and hasattr(editor, 'force_auto_complete'):
            editor.force_auto_complete()

    def fix_indentation_current(self):
        """Corrige indentação no editor atual"""
        editor, _ = self.get_current_editor()
        if editor and hasattr(editor, 'fix_indentation'):
            editor.fix_indentation()

    def pause_execution(self):
        """Pausa execução"""
        # Implementação básica - para processos subprocess
        self.statusBar().showMessage("⏸️ Execução pausada", 2000)

    def stop_execution(self):
        """Para execução"""
        # Para processos em execução
        self.statusBar().showMessage("⏹️ Execução parada", 2000)

    def run_tests(self):
        """Executa testes"""
        if not self.project_path:
            QMessageBox.information(self, "Informação", "Nenhum projeto aberto.")
            return

        try:
            python_exec = self.get_python_executable()
            result = subprocess.run(
                [python_exec, "-m", "pytest"],
                capture_output=True,
                text=True,
                cwd=self.project_path
            )

            self.output_tabs.setCurrentWidget(self.output_text)
            self.output_text.clear()
            self.output_text.appendPlainText("🧪 Executando testes...\n")

            if result.stdout:
                self.output_text.appendPlainText(result.stdout)
            if result.stderr:
                self.output_text.appendPlainText(result.stderr)

        except Exception as e:
            self.output_text.appendPlainText(f"❌ Erro ao executar testes: {str(e)}")

    def run_coverage(self):
        """Executa coverage"""
        if not self.project_path:
            return

        try:
            python_exec = self.get_python_executable()
            result = subprocess.run(
                [python_exec, "-m", "coverage", "run", "-m", "pytest"],
                capture_output=True,
                text=True,
                cwd=self.project_path
            )

            self.output_tabs.setCurrentWidget(self.output_text)
            self.output_text.clear()
            self.output_text.appendPlainText("📊 Gerando coverage...\n")

            if result.returncode == 0:
                # Mostra report
                report_result = subprocess.run(
                    [python_exec, "-m", "coverage", "report"],
                    capture_output=True,
                    text=True,
                    cwd=self.project_path
                )

                if report_result.stdout:
                    self.output_text.appendPlainText(report_result.stdout)
            else:
                self.output_text.appendPlainText("❌ Erro no coverage")

        except Exception as e:
            self.output_text.appendPlainText(f"❌ Erro: {str(e)}")
