
import os
import subprocess
import shutil
import glob
import json
import inspect
import importlib.util
import ast
import platform
import time
import re
from typing import Dict, Set, List, Any
import threading
import textwrap

from PySide6.QtWidgets import (
    QApplication, QMainWindow, QDockWidget, QPlainTextEdit,
    QFileSystemModel, QTreeView, QTabWidget, QToolBar,
    QFileDialog, QInputDialog, QMessageBox, QComboBox,
    QMenu, QSplitter, QVBoxLayout, QWidget, QListWidget, QListWidgetItem,
    QStyledItemDelegate, QDialog, QVBoxLayout as QVBoxLayoutDialog, QLabel, QPushButton,
    QCompleter, QProgressBar, QHBoxLayout, QLineEdit
)
from PySide6.QtGui import (
    QAction, QPalette, QColor, QFont, QSyntaxHighlighter, QTextCharFormat, QTextCursor,
    QKeyEvent, QTextBlockUserData, QTextOption, QPainter, QFontDatabase, QGuiApplication, QShortcut
)
from PySide6.QtCore import Qt, QDir, QRegularExpression, QProcess, QTimer, QModelIndex, QThread, Signal, \
    QStringListModel, QSize
import os
import json
from typing import Dict, List, Set, Any





class LoadingWidget(QWidget):
    """Widget de carregamento para o autocomplete"""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setup_ui()

    def setup_ui(self):
        layout = QVBoxLayout()
        layout.setContentsMargins(5, 2, 5, 2)

        # Barra de progresso
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 0)  # Modo indeterminado
        self.progress_bar.setFixedHeight(6)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: none;
                background-color: #2d2d30;
                border-radius: 3px;
            }
            QProgressBar::chunk {
                background-color: #569cd6;
                border-radius: 3px;
            }
        """)

        # Texto de carregamento
        self.loading_label = QLabel("🔄 Carregando sugestões...")
        self.loading_label.setStyleSheet("color: #9cdcfe; font-size: 10px;")
        self.loading_label.setAlignment(Qt.AlignCenter)

        layout.addWidget(self.progress_bar)
        layout.addWidget(self.loading_label)
        self.setLayout(layout)
        self.hide()


# Instância global do gerenciador de cache
module_cache_manager = ModuleCacheManager()





class ErrorData(QTextBlockUserData):
    def __init__(self, errors=None):
        super().__init__()
        self.errors = errors or []








class LineNumberArea(QWidget):
    def __init__(self, editor):
        super().__init__(editor)
        self.editor = editor
        self.setFixedWidth(70)  # Increased width for better alignment

    def update_line_numbers(self):
        self.update()

    def update_line_numbers_area(self, rect, dy):
        if dy:
            self.scroll(0, dy)
        else:
            self.update(0, rect.y(), self.width(), rect.height())
        if rect.contains(self.editor.viewport().rect()):
            self.update_line_numbers()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.fillRect(event.rect(), QColor(20, 30, 48))  # Match dark theme
        block = self.editor.firstVisibleBlock()
        block_number = block.blockNumber()
        top = int(self.editor.blockBoundingGeometry(block).translated(self.editor.contentOffset()).top())
        bottom = top + int(self.editor.blockBoundingRect(block).height())
        font = self.editor.font()
        font.setPointSize(10)
        painter.setFont(font)
        font_metrics = self.editor.fontMetrics()

        while block.isValid() and top <= event.rect().bottom():
            if block.isVisible() and bottom >= event.rect().top():
                number = str(block_number + 1)
                painter.setPen(QColor(150, 150, 150))  # Light gray for line numbers
                painter.drawText(0, top, 50, font_metrics.height(), Qt.AlignRight, number)

                # Draw vertical separator
                painter.setPen(QColor(100, 100, 100))  # Gray vertical line
                painter.drawLine(55, top, 55, bottom)

                # Draw red line for errors
                data = block.userData()
                if isinstance(data, ErrorData) and any(error['type'] == 'error' for error in data.errors):
                    painter.setPen(QColor(255, 0, 0))  # Red line for errors
                    painter.drawLine(60, top, 60, bottom)

            block = block.next()
            top = bottom
            bottom = top + int(self.editor.blockBoundingRect(block).height())
            block_number += 1


class AutoCompleteWidget(QListWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowFlags(Qt.ToolTip)
        self.setMaximumHeight(120)  # Reduzido para ser menos intrusivo
        self.setMaximumWidth(300)
        self.current_editor = None

        # Estilo otimizado para performance
        self.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)

    def show_suggestions(self, editor, suggestions):
        self.current_editor = editor
        self.clear()

        if not suggestions:
            self.hide()
            return

        # Adiciona sugestões rapidamente
        for suggestion in suggestions[:8]:  # Apenas 8 sugestões para resposta rápida
            self.addItem(suggestion)

        # Posicionamento otimizado
        cursor_rect = editor.cursorRect()
        pos = editor.mapToGlobal(cursor_rect.bottomLeft())
        self.move(pos)
        self.show()
        self.setCurrentRow(0)  # Seleciona primeiro item
        self.setFocus()

    def insert_completion(self, completion):
        if not self.current_editor:
            return

        cursor = self.current_editor.textCursor()
        cursor.insertText(completion)
        self.hide()








class Minimap(QPlainTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setReadOnly(True)
        self.setFont(QFont("Monospace", 4))
        self.setWordWrapMode(QTextOption.NoWrap)


class ProblemsDelegate(QStyledItemDelegate):
    def paint(self, painter: QPainter, option, index):
        super().paint(painter, option, index)
        data = index.data(Qt.UserRole)
        if data:
            error_type = data.get('type', 'info')
            color = QColor("red") if error_type == 'error' else QColor("yellow") if error_type == 'warning' else QColor(
                "blue")
            painter.setPen(color)
            painter.drawText(option.rect.x() + 5, option.rect.bottom() - 5, "●")




class TerminalTextEdit(QPlainTextEdit):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.input_start = 0
        self.setFont(QFont("Monospace", 10))
        self.setStyleSheet("background-color: #1e1e1e; color: #ffffff;")

        # Histórico de comandos
        self.history = []
        self.history_index = -1

        # Configurar prompt inicial
        self.setPlainText(">>> ")
        self.input_start = 4  # Posição após ">>> "

        # Mover cursor para o final
        cursor = self.textCursor()
        cursor.movePosition(QTextCursor.End)
        self.setTextCursor(cursor)

    def append_output(self, output):
        """Adiciona saída ao terminal - MÉTODO ADICIONADO"""
        cursor = self.textCursor()
        cursor.movePosition(QTextCursor.End)
        self.setTextCursor(cursor)
        self.insertPlainText(output)

        # Atualiza input_start
        self.input_start = len(self.toPlainText())

        # Move cursor para o final
        cursor.movePosition(QTextCursor.End)
        self.setTextCursor(cursor)

        # Rola para baixo
        self.ensureCursorVisible()

    def keyPressEvent(self, event: QKeyEvent):
        cursor = self.textCursor()
        cursor_position = cursor.position()

        # Impede edição antes do input_start
        if cursor_position < self.input_start and event.key() not in [Qt.Key_Return, Qt.Key_Enter, Qt.Key_Up,
                                                                      Qt.Key_Down]:
            cursor.movePosition(QTextCursor.End)
            self.setTextCursor(cursor)
            event.accept()
            return

        # Enter - executa comando
        if event.key() in [Qt.Key_Return, Qt.Key_Enter]:
            self.execute_command()
            event.accept()
            return

        # Setas para navegar no histórico
        elif event.key() == Qt.Key_Up:
            self.navigate_history(-1)
            event.accept()
            return
        elif event.key() == Qt.Key_Down:
            self.navigate_history(1)
            event.accept()
            return

        # Ctrl+C - interrompe processo
        elif event.key() == Qt.Key_C and event.modifiers() == Qt.ControlModifier:
            self.interrupt_process()
            event.accept()
            return

        # Ctrl+L - limpa terminal
        elif event.key() == Qt.Key_L and event.modifiers() == Qt.ControlModifier:
            self.clear_terminal()
            event.accept()
            return

        # Backspace - impede apagar o prompt
        elif event.key() == Qt.Key_Backspace:
            if cursor_position > self.input_start:
                super().keyPressEvent(event)
            event.accept()
            return

        # Delete - impede apagar o prompt
        elif event.key() == Qt.Key_Delete:
            if cursor_position >= self.input_start:
                super().keyPressEvent(event)
            event.accept()
            return

        # Teclas normais - apenas se estiver após o prompt
        elif cursor_position >= self.input_start:
            super().keyPressEvent(event)

        else:
            # Move para o final se tentar digitar antes do prompt
            cursor.movePosition(QTextCursor.End)
            self.setTextCursor(cursor)

    def execute_command(self):
        """Executa o comando atual"""
        cursor = self.textCursor()
        cursor.select(QTextCursor.LineUnderCursor)
        command_line = cursor.selectedText().strip()

        # Remove o prompt se existir
        if command_line.startswith(">>> "):
            command = command_line[4:]
        else:
            command = command_line

        if command:
            # Adiciona ao histórico
            self.history.append(command)
            self.history_index = len(self.history)

            # Executa o comando
            self.run_command(command)

        # Novo prompt
        self.append_output("\n>>> ")

    def run_command(self, command):
        """Executa um comando no shell"""
        try:
            ide = self.get_ide()
            if ide and ide.shell_process:
                # Envia o comando para o processo do shell
                ide.shell_process.write(f"{command}\n".encode())
        except Exception as e:
            self.append_output(f"\nErro: {str(e)}")

    def navigate_history(self, direction):
        """Navega pelo histórico de comandos"""
        if not self.history:
            return

        new_index = self.history_index + direction

        if 0 <= new_index < len(self.history):
            self.history_index = new_index
            self.replace_current_line(self.history[self.history_index])
        elif new_index == len(self.history):
            self.history_index = new_index
            self.replace_current_line("")

    def replace_current_line(self, text):
        """Substitui a linha atual por novo texto"""
        cursor = self.textCursor()
        cursor.select(QTextCursor.LineUnderCursor)
        cursor.removeSelectedText()
        cursor.insertText(f">>> {text}")

        # Move cursor para o final
        cursor.movePosition(QTextCursor.End)
        self.setTextCursor(cursor)
        self.input_start = len(self.toPlainText()) - len(text)

    def interrupt_process(self):
        """Interrompe o processo atual (Ctrl+C)"""
        try:
            ide = self.get_ide()
            if ide and ide.shell_process:
                # Envia sinal de interrupção
                if os.name == 'nt':  # Windows
                    ide.shell_process.kill()
                else:  # Linux/Mac
                    ide.shell_process.terminate()

                self.append_output("\n^C")
                # Reinicia o shell
                self.restart_shell()
        except Exception as e:
            self.append_output(f"\nErro ao interromper: {str(e)}")

    def clear_terminal(self):
        """Limpa o terminal (Ctrl+L)"""
        self.clear()
        self.setPlainText(">>> ")
        self.input_start = 4
        cursor = self.textCursor()
        cursor.movePosition(QTextCursor.End)
        self.setTextCursor(cursor)

    def restart_shell(self):
        """Reinicia o processo do shell"""
        try:
            ide = self.get_ide()
            if ide:
                # Para processo atual
                if ide.shell_process and ide.shell_process.state() == QProcess.Running:
                    ide.shell_process.terminate()
                    ide.shell_process.waitForFinished(1000)

                # Inicia novo processo
                ide.shell_process = QProcess(ide)
                ide.shell_process.readyReadStandardOutput.connect(ide.handle_terminal_output)
                ide.shell_process.readyReadStandardError.connect(ide.handle_terminal_error)

                if os.name == 'nt':  # Windows
                    ide.shell_process.start("cmd.exe")
                else:  # Linux/Mac
                    ide.shell_process.start("/bin/bash", ["-i"])

                # Configura diretório do projeto se existir
                if ide.project_path:
                    ide.activate_project()

                self.append_output("\nShell reiniciado\n>>> ")

        except Exception as e:
            self.append_output(f"\nErro ao reiniciar shell: {str(e)}")

    def get_ide(self):
        """Encontra a instância do IDE pai"""
        parent = self.parent()
        while parent and not isinstance(parent, IDE):
            if hasattr(parent, 'parent'):
                parent = parent.parent()
            else:
                parent = None
        return parent


# Classe PackageDialog adicionada para corrigir o erro




class StatusBarProgress(QWidget):
    """Widget de progresso para a barra de status - CORRIGIDO"""

    def __init__(self, parent=None):
        super().__init__(parent)  # CORREÇÃO: Chamar __init__ da classe base
        self.setup_ui()

    def setup_ui(self):
        layout = QHBoxLayout()
        layout.setContentsMargins(5, 2, 5, 2)

        # Ícone
        self.icon_label = QLabel("🔄")
        self.icon_label.setStyleSheet("font-size: 14px;")
        layout.addWidget(self.icon_label)

        # Texto
        self.text_label = QLabel("Carregando...")
        self.text_label.setStyleSheet("color: #9cdcfe; font-size: 12px;")
        layout.addWidget(self.text_label)

        # Barra de progresso pequena
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setFixedHeight(6)
        self.progress_bar.setFixedWidth(100)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: 1px solid #3c3c3c;
                border-radius: 3px;
                background-color: #1e1e1e;
            }
            QProgressBar::chunk {
                background-color: #569cd6;
                border-radius: 2px;
            }
        """)
        layout.addWidget(self.progress_bar)

        # Botão fechar
        self.close_btn = QPushButton("×")
        self.close_btn.setFixedSize(16, 16)
        self.close_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #cccccc;
                border: none;
                font-size: 12px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #d84f4f;
                color: white;
                border-radius: 2px;
            }
        """)
        self.close_btn.clicked.connect(self.hide)
        layout.addWidget(self.close_btn)

        self.setLayout(layout)
        self.hide()

    def update_progress(self, value, message=""):
        """Atualiza o progresso"""
        self.progress_bar.setValue(value)
        if message:
            self.text_label.setText(message)

    def show_loading(self, message="Carregando..."):
        """Mostra o widget de carregamento"""
        self.icon_label.setText("🔄")
        self.text_label.setText(message)
        self.progress_bar.setValue(0)
        self.show()

    def show_success(self, message="Concluído!"):
        """Mostra sucesso"""
        self.icon_label.setText("✅")
        self.text_label.setText(message)
        self.progress_bar.setValue(100)
        QTimer.singleShot(2000, self.hide)  # Esconde após 2 segundos

    def show_error(self, message="Erro!"):
        """Mostra erro"""
        self.icon_label.setText("❌")
        self.text_label.setText(message)
        self.progress_bar.setValue(0)
        QTimer.singleShot(3000, self.hide)  # Esconde após 3 segundos


# NOVO: Visitor para relações de classe
class ClassRelationVisitor(ast.NodeVisitor):
    """Visitor para detectar relações entre classes e métodos"""

    def __init__(self):
        self.classes = set()
        self.methods = {}
        self.current_class = None

    def visit_ClassDef(self, node):
        self.current_class = node.name
        self.classes.add(node.name)
        self.generic_visit(node)
        self.current_class = None

    def visit_FunctionDef(self, node):
        if self.current_class:
            if self.current_class not in self.methods:
                self.methods[self.current_class] = set()
            self.methods[self.current_class].add(node.name)
        self.generic_visit(node)







import sys
from PySide6.QtWidgets import QApplication
from ide_main import IDE

if __name__ == "__main__":
    try:
        app = QApplication(sys.argv)
        window = IDE()
        window.show()
        sys.exit(app.exec())
    except Exception as e:
        print(f"Erro: {e}")
        import traceback
        traceback.print_exc()
        input("Enter para sair")