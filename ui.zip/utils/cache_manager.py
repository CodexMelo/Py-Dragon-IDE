

import os
import re
import time
import threading
import ast
import importlib.util
from typing import Dict, Set, List, Any

class ModuleCacheManager:
    """Gerenciador de cache para módulos e métodos - MELHORADO COM CACHING DE CADEIAS E PRELOAD"""

    def __init__(self):
        self._cache_lock = threading.RLock()
        self._module_cache: Dict[str, Dict[str, Any]] = {}  # Cache principal: módulo -> {método: sub-métodos}
        self._project_modules: Dict[str, Set[str]] = {}
        self._last_scan_time: Dict[str, float] = {}
        self._scan_interval = 5.0  # Aumentado para 5s para reduzir scans frequentes
        self._chain_cache: Dict[str, Set[str]]

    def preload_all_project_modules(self, project_path: str, file_path: str = None):
        """PRELOAD AGRESSIVO: Carrega todos os módulos do projeto uma vez"""
        if self._preload_done or not project_path:
            return

        with self._cache_lock:
            self._preload_done = True
            print("🔄 Preloading todos os módulos do projeto... (pode demorar)")

            # Encontra todos os .py no projeto
            py_files = []
            for root, dirs, files in os.walk(project_path):
                for file in files:
                    if file.endswith('.py') and not file.startswith('__'):
                        py_files.append(os.path.join(root, file))

            # Carrega cada um
            for py_file in py_files:
                module_name = os.path.relpath(py_file, project_path).replace(os.sep, '.').rstrip('.py')
                self.get_module_methods(module_name, py_file, project_path)  # Força scan

            print("✅ Preload concluído!")

    def get_module_methods(self, module_name: str, file_path: str = None, project_path: str = None) -> Set[str]:
        """Obtém todos os métodos de um módulo com cache - MELHORADO PARA SUB-MÉTODOS"""
        with self._cache_lock:
            cache_key = f"{module_name}:{file_path or ''}"

            # Verifica se precisa atualizar o cache
            current_time = time.time()
            last_scan = self._last_scan_time.get(cache_key, 0)

            if current_time - last_scan > self._scan_interval:
                self._update_module_cache(module_name, file_path, project_path)
                self._last_scan_time[cache_key] = current_time

            methods = self._module_cache.get(cache_key, set())
            # Retorna como set de strings com () para consistência
            return {m if m.endswith('()') else f"{m}()" for m in methods}

    def get_chain_methods(self, chain: str, file_path: str = None, project_path: str = None) -> Set[str]:
        """NOVO: Obtém métodos para uma cadeia como 'obj.method'"""
        cache_key = f"chain:{chain}:{file_path or ''}"
        if cache_key in self._chain_cache:
            return self._chain_cache[cache_key]

        # Extrai base module e subpath
        parts = chain.split('.')
        base_module = parts[0]
        sub_path = '.'.join(parts[1:])

        base_methods = self.get_module_methods(base_module, file_path, project_path)
        sub_methods = set()

        for method in base_methods:
            method_name = method.rstrip('()')
            if method_name == sub_path:
                # Encontrou o sub-método, adiciona seus filhos
                full_method_key = f"{base_module}.{method_name}"
                sub_methods.update(self._get_sub_methods(full_method_key, file_path, project_path))

        self._chain_cache[cache_key] = sub_methods
        return sub_methods

    def _get_sub_methods(self, full_method: str, file_path: str = None, project_path: str = None) -> Set[str]:
        """Extrai sub-métodos de um método/classe específico"""
        subs = set()
        # Para simplificação, usa padrões comuns ou análise AST mais profunda
        # Expansão futura: análise de retornos de funções para inferir tipos
        common_subs = {
            'list': ['append()', 'remove()', 'pop()', 'sort()', 'reverse()', 'index()', 'count()'],
            'dict': ['get()', 'keys()', 'values()', 'items()', 'update()', 'pop()', 'clear()'],
            'str': ['upper()', 'lower()', 'strip()', 'split()', 'join()', 'replace()', 'find()', 'startswith()'],
            'int': ['bit_length()', '__str__()', 'abs()'],
            # Adicione mais baseados em inferência
        }
        base_name = full_method.split('.')[-1].rstrip('()')
        for key, methods in common_subs.items():
            if key in base_name.lower():
                subs.update(methods)
                break
        return subs

    def _update_module_cache(self, module_name: str, file_path: str = None, project_path: str = None):
        """Atualiza o cache para um módulo específico - MELHORADO COM AST ROBUSTA"""
        cache_key = f"{module_name}:{file_path or ''}"
        methods = set()

        try:
            # Tenta carregar como módulo Python padrão
            if module_name in sys.builtin_module_names:
                methods.update(self._get_builtin_module_methods(module_name))

            # Tenta importar o módulo
            try:
                spec = importlib.util.find_spec(module_name)
                if spec and spec.loader:
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    methods.update(self._get_module_attributes(module))
            except:
                pass

            # Procura módulos locais no projeto
            if project_path:
                local_methods = self._scan_local_module(module_name, project_path, file_path)
                methods.update(local_methods)

            # Procura no arquivo atual
            if file_path and os.path.exists(file_path):
                current_file_methods = self._scan_file_for_imports(file_path, module_name)
                methods.update(current_file_methods)

            # Adiciona métodos comuns baseados no nome do módulo
            common_methods = self._get_common_module_methods(module_name)
            methods.update(common_methods)

        except Exception as e:
            print(f"Erro ao atualizar cache para {module_name}: {e}")

        self._module_cache[cache_key] = methods

    def _get_builtin_module_methods(self, module_name: str) -> Set[str]:
        """Métodos para módulos built-in - EXPANDIDO"""
        builtin_methods = {
            'os': ['path.join()', 'path.exists()', 'path.dirname()', 'path.basename()', 'mkdir()', 'listdir()', 'getcwd()', 'chdir()', 'remove()', 'rename()', 'system()', 'environ'],
            'sys': ['argv', 'path', 'exit()', 'version', 'platform', 'modules', 'executable'],
            'json': ['loads()', 'dumps()', 'load()', 'dump()'],
            're': ['search()', 'match()', 'findall()', 'sub()', 'compile()', 'IGNORECASE', 'MULTILINE'],
            'datetime': ['datetime', 'date', 'time', 'timedelta', 'now()', 'today()', 'strftime()'],
            'math': ['sqrt()', 'sin()', 'cos()', 'pi', 'e', 'log()', 'ceil()', 'floor()', 'radians()'],
            'random': ['random()', 'randint()', 'choice()', 'shuffle()', 'uniform()', 'seed()'],
            'subprocess': ['run()', 'call()', 'Popen()', 'check_output()', 'DEVNULL', 'PIPE'],
            'shutil': ['copy()', 'move()', 'rmtree()', 'which()', 'copytree()', 'make_archive()'],
            'glob': ['glob()', 'iglob()'],
            'ast': ['parse()', 'walk()', 'NodeVisitor', 'literal_eval()'],
            'inspect': ['getsource()', 'signature()', 'getmembers()', 'isfunction()', 'isclass()'],
            'importlib': ['import_module()', 'util', 'reload()'],
            'platform': ['system()', 'version()', 'machine()', 'python_version()'],
            'time': ['sleep()', 'time()', 'ctime()', 'strftime()', 'localtime()'],
            'pathlib': ['Path()', 'PurePath()'],
            'collections': ['deque()', 'Counter()', 'defaultdict()', 'namedtuple()', 'OrderedDict()'],
            'itertools': ['chain()', 'cycle()', 'combinations()', 'permutations()', 'product()'],
            'functools': ['partial()', 'reduce()', 'wraps()', 'lru_cache()'],
            'threading': ['Thread()', 'Lock()', 'Event()', 'Timer()'],
            'multiprocessing': ['Process()', 'Pool()', 'Queue()', 'Manager()'],
            'tkinter': ['Tk()', 'Button()', 'Label()', 'Entry()', 'Text()', 'filedialog', 'messagebox'],
            'PySide6': ['QtWidgets', 'QtCore', 'QtGui'],
            'PySide6.QtWidgets': ['QApplication()', 'QMainWindow()', 'QPushButton()', 'QLabel()'],
            'PySide6.QtCore': ['Qt', 'QTimer()', 'Signal()', 'Slot()'],
            'PySide6.QtGui': ['QPalette()', 'QColor()', 'QFont()']
        }
        return set(builtin_methods.get(module_name, []))

    def _get_module_attributes(self, module) -> Set[str]:
        """Extrai atributos de um módulo importado - MELHORADO PARA SUB-ATRIOS"""
        attrs = set()
        try:
            for attr_name in dir(module):
                if not attr_name.startswith('_'):
                    attr = getattr(module, attr_name)
                    if callable(attr):
                        attrs.add(f"{attr_name}()")
                        # NOVO: Se é callable, tenta extrair sub-métodos se possível
                        if hasattr(attr, '__doc__') and 'class' in str(type(attr)).lower():
                            subs = self._extract_class_methods(attr)
                            for sub in subs:
                                attrs.add(f"{attr_name}.{sub}")
                    else:
                        attrs.add(attr_name)
        except:
            pass
        return attrs

    def _extract_class_methods(self, cls) -> Set[str]:
        """Extrai métodos de uma classe dinamicamente"""
        subs = set()
        for sub_name in dir(cls):
            if not sub_name.startswith('_') and callable(getattr(cls, sub_name)):
                subs.add(f"{sub_name}()")
        return subs

    def _scan_local_module(self, module_name: str, project_path: str, current_file: str = None) -> Set[str]:
        """Escaneia módulos locais no projeto - MELHORADO COM AST ROBUSTA"""
        methods = set()

        try:
            # Possíveis locais do módulo
            possible_paths = [
                os.path.join(project_path, f"{module_name}.py"),
                os.path.join(project_path, module_name, "__init__.py"),
                os.path.join(project_path, "src", f"{module_name}.py"),
                os.path.join(project_path, "lib", f"{module_name}.py"),
            ]

            # Se temos um arquivo atual, procura no mesmo diretório
            if current_file:
                current_dir = os.path.dirname(current_file)
                possible_paths.extend([
                    os.path.join(current_dir, f"{module_name}.py"),
                    os.path.join(current_dir, module_name, "__init__.py"),
                ])

            for module_path in possible_paths:
                if os.path.exists(module_path):
                    module_methods = self._parse_python_file_robust(module_path)
                    methods.update(module_methods)
                    break

            # Procura por imports relativos
            if current_file and '.' in module_name:
                relative_methods = self._handle_relative_imports(module_name, current_file, project_path)
                methods.update(relative_methods)

        except Exception as e:
            print(f"Erro ao escanear módulo local {module_name}: {e}")

        return methods

    def _parse_python_file_robust(self, file_path: str) -> Set[str]:
        """Analisa um arquivo Python com AST robusta - CORRIGIDO PARA ERROS DE INDENT"""
        methods = set()

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # Tenta AST com modo 'exec' e ignore erros de indent
            tree = None
            try:
                tree = ast.parse(content, mode='exec', filename=file_path)
            except (IndentationError, SyntaxError) as e:
                # Corrige indentação básica antes de parse - MELHORADO
                lines = content.splitlines()
                fixed_lines = []
                current_indent = 0
                for line_num, line in enumerate(lines, 1):
                    stripped = line.lstrip()
                    if stripped.startswith(('def ', 'class ', 'if ', 'for ', 'while ', 'try ', 'except ', 'else:', 'elif ')):
                        # Detecta novo bloco
                        current_indent = len(line) - len(stripped)
                    elif not stripped:
                        # Linha vazia mantém indent
                        fixed_lines.append(' ' * current_indent)
                        continue
                    else:
                        # Ajusta indent se inconsistente
                        actual_indent = len(line) - len(stripped)
                        if actual_indent % 4 != 0:  # Assume 4 spaces
                            fixed_lines.append(' ' * (current_indent + (actual_indent % 4)))
                        else:
                            fixed_lines.append(line)
                    fixed_lines.append(' ' * current_indent + stripped if not line.startswith(' ' * current_indent) else line)
                fixed_content = '\n'.join(fixed_lines)
                try:
                    tree = ast.parse(fixed_content, mode='exec', filename=file_path)
                    print(f"Indentação corrigida com sucesso para {file_path}")
                except Exception as fix_e:
                    print(f"Correção de indent falhou para {file_path}: {fix_e}")
                    return self._parse_with_regex(content)
            except Exception as parse_e:
                print(f"AST ainda falhou para {file_path}: {parse_e}")
                # Fallback regex melhorado
                return self._parse_with_regex(content)

            # Visita AST
            visitor = DefinitionVisitor()
            visitor.visit(tree)
            methods.update(visitor.definitions)

        except Exception as e:
            print(f"Erro ao analisar arquivo {file_path}: {e}")
            # Fallback global
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                methods.update(self._parse_with_regex(content))
            except:
                pass

        return methods

    def _parse_with_regex(self, content: str) -> Set[str]:
        """Fallback regex melhorado para defs, classes e assigns"""
        methods = set()
        # Funções
        functions = re.findall(r'def\s+([a-zA-Z_][a-zA-Z0-9_]*)', content)
        methods.update([f"{f}()" for f in functions])
        # Classes
        classes = re.findall(r'class\s+([a-zA-Z_][a-zA-Z0-9_]*)', content)
        methods.update(classes)
        # Atribuições de vars
        var_matches = re.findall(r'^(\s*)([a-zA-Z_][a-zA-Z0-9_]*)\s*=', content, re.MULTILINE)
        for indent, var in var_matches:
            if len(var) > 2 and not var.startswith('_'):
                methods.add(var)
        return methods

    def _scan_file_for_imports(self, file_path: str, target_module: str) -> Set[str]:
        """Escaneia um arquivo específico para imports relacionados - MELHORADO COM AST ROBUSTA"""
        methods = set()

        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # Análise AST robusta
            tree = None
            try:
                tree = ast.parse(content, mode='exec', filename=file_path)
            except (IndentationError, SyntaxError, Exception) as e:
                print(f"AST falhou para {file_path} (usando regex fallback): {e}")
                methods.update(self._find_imports_regex(content, target_module))
                return methods

            visitor = DefinitionVisitor()
            visitor.visit(tree)

            # Filtra imports relacionados ao target
            for imp in visitor.import_statements:
                if target_module in imp:
                    # Encontra usos
                    usage_methods = self._find_module_usage(content, target_module)
                    methods.update(usage_methods)

            # Adiciona defs locais
            methods.update(visitor.definitions)

        except Exception as e:
            print(f"Erro ao escanear imports em {file_path}: {e}")
            methods.update(self._find_imports_regex(content, target_module))

        return methods

    def _find_imports_regex(self, content: str, target_module: str) -> Set[str]:
        """Fallback regex para encontrar imports e métodos relacionados - MELHORADO"""
        methods = set()
        # Regex para imports
        import_patterns = [
            rf'import\s+{re.escape(target_module)}(\s+as\s+([a-zA-Z_][a-zA-Z0-9_]*))?',
            rf'from\s+{re.escape(target_module)}\s+import\s+([a-zA-Z_][a-zA-Z0-9_]*)'
        ]
        for pattern in import_patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            for match in matches:
                if isinstance(match, tuple):
                    for item in match:
                        if item and item not in ['', ' ']:
                            methods.add(item)
                else:
                    if match and match not in ['', ' ']:
                        methods.add(match)
        # Usos
        methods.update(self._find_module_usage(content, target_module))
        return methods

    def _find_module_usage(self, content: str, module_name: str, alias: str = None) -> Set[str]:
        """Encontra usos de um módulo no código - MELHORADO PARA CADEIAS"""
        methods = set()
        used_name = alias or module_name

        # Métodos: modulo.metodo(args)
        pattern = rf'{re.escape(used_name)}\.([a-zA-Z_][a-zA-Z0-9_]*)\s*\('
        matches = re.findall(pattern, content)
        methods.update([f"{match}()" for match in matches])

        # Atributos: modulo.attr
        attr_pattern = rf'{re.escape(used_name)}\.([a-zA-Z_][a-zA-Z0-9_]*)(?![a-zA-Z0-9_])'
        attr_matches = re.findall(attr_pattern, content)
        methods.update(attr_matches)

        # NOVO: Cadeias como modulo.method.submethod
        chain_pattern = rf'{re.escape(used_name)}\.([a-zA-Z_][a-zA-Z0-9_]*)\.([a-zA-Z_][a-zA-Z0-9_]*)'
        chain_matches = re.findall(chain_pattern, content)
        for base, sub in chain_matches:
            methods.add(f"{base}.{sub}()")

        return methods

    def _handle_relative_imports(self, module_name: str, current_file: str, project_path: str) -> Set[str]:
        """Lida com imports relativos - MELHORADO"""
        methods = set()

        try:
            current_dir = os.path.dirname(current_file)
            relative_parts = module_name.split('.')

            if relative_parts[0] == '':
                relative_parts = relative_parts[1:]
                base_path = current_dir
            else:
                base_path = project_path

            abs_path = os.path.join(base_path, *relative_parts[:-1])
            target_module = relative_parts[-1]

            module_files = [
                os.path.join(abs_path, f"{target_module}.py"),
                os.path.join(abs_path, target_module, "__init__.py")
            ]

            for module_file in module_files:
                if os.path.exists(module_file):
                    module_methods = self._parse_python_file_robust(module_file)
                    methods.update(module_methods)
                    break

        except Exception as e:
            print(f"Erro com import relativo {module_name}: {e}")

        return methods

    def _get_common_module_methods(self, module_name: str) -> Set[str]:
        """Métodos comuns baseados em padrões de nomes de módulos"""
        common_patterns = {
            'utils': ['helper()', 'utility()', 'format()', 'validate()', 'parse()'],
            'config': ['load()', 'save()', 'get()', 'set()', 'update()'],
            'database': ['connect()', 'query()', 'insert()', 'update()', 'delete()', 'commit()'],
            'api': ['request()', 'get()', 'post()', 'put()', 'delete()', 'authenticate()'],
            'handler': ['handle()', 'process()', 'execute()', 'run()'],
            'manager': ['create()', 'read()', 'update()', 'delete()', 'list()', 'find()'],
            'service': ['execute()', 'process()', 'handle()', 'run()']
        }

        for pattern, methods in common_patterns.items():
            if pattern in module_name.lower():
                return set(methods)

        return set()

    def clear_cache(self, module_name: str = None):
        """Limpa o cache, opcionalmente para um módulo específico"""
        with self._cache_lock:
            if module_name:
                keys_to_remove = [k for k in self._module_cache.keys() if k.startswith(module_name)]
                for key in keys_to_remove:
                    self._module_cache.pop(key, None)
                    self._last_scan_time.pop(key, None)
                self._chain_cache.clear()
            else:
                self._module_cache.clear()
                self._last_scan_time.clear()
                self._chain_cache.clear()
            self._preload_done = False

    def force_rescan(self, module_name: str, file_path: str = None):
        """Força uma reanálise do módulo"""
        cache_key = f"{module_name}:{file_path or ''}"
        self._last_scan_time.pop(cache_key, None)
        self._module_cache.pop(cache_key, None)
        self._chain_cache.clear()  # Limpa chains relacionadas
