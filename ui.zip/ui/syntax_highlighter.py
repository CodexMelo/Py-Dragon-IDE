




class MultiLanguageHighlighter(QSyntaxHighlighter):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.language_config = LanguageConfig()
        self.current_language = 'Text'
        self.highlighting_rules = []
        self.comment_format = QTextCharFormat()
        self.comment_format.setForeground(QColor("#6a9955"))

    def set_language(self, file_path):
        self.current_language = self.language_config.get_language_from_extension(file_path)
        self.setup_highlighting_rules()

    def setup_highlighting_rules(self):
        self.highlighting_rules = []

        if self.current_language == 'Python':
            self.setup_python_rules()
        elif self.current_language == 'JavaScript':
            self.setup_javascript_rules()
        elif self.current_language == 'HTML':
            self.setup_html_rules()
        elif self.current_language == 'CSS':
            self.setup_css_rules()
        elif self.current_language == 'JSON':
            self.setup_json_rules()
        elif self.current_language == 'SQL':
            self.setup_sql_rules()
        elif self.current_language == 'Java':
            self.setup_java_rules()
        elif self.current_language == 'C++' or self.current_language == 'C':
            self.setup_cpp_rules()
        elif self.current_language == 'C#':
            self.setup_csharp_rules()
        elif self.current_language == 'PHP':
            self.setup_php_rules()
        elif self.current_language == 'Ruby':
            self.setup_ruby_rules()
        elif self.current_language == 'Go':
            self.setup_go_rules()
        elif self.current_language == 'Rust':
            self.setup_rust_rules()
        elif self.current_language == 'Swift':
            self.setup_swift_rules()
        elif self.current_language == 'Kotlin':
            self.setup_kotlin_rules()
        elif self.current_language == 'XML':
            self.setup_xml_rules()
        elif self.current_language == 'Markdown':
            self.setup_markdown_rules()
        elif self.current_language == 'YAML':
            self.setup_yaml_rules()
        else:
            self.setup_basic_rules()


    def setup_python_rules(self):
        # Keywords (organizadas por categoria para padrões da linguagem Python)
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569cd6"))
        keyword_format.setFontWeight(QFont.Bold)
        keywords = [
            # Control flow
            "if", "else", "elif", "for", "while", "break", "continue", "pass", "return",
            # Exceptions
            "try", "except", "finally", "raise",
            # Functions and classes
            "def", "class", "lambda", "global", "nonlocal",
            # Imports
            "import", "from", "as",
            # Logical
            "and", "or", "not", "in", "is",
            # Constants
            "True", "False", "None"
        ]
        for word in keywords:
            pattern = QRegularExpression(r'\b' + word + r'\b')
            self.highlighting_rules.append((pattern, keyword_format))

        # Built-in functions (destaque sutil para diferenciar de user-defined)
        builtin_format = QTextCharFormat()
        builtin_format.setForeground(QColor("#4ec9b0"))
        builtins = [
            "abs", "all", "any", "ascii", "bin", "bool", "bytearray", "bytes", "callable",
            "chr", "classmethod", "compile", "complex", "delattr", "dict", "dir", "divmod",
            "enumerate", "eval", "exec", "filter", "float", "format", "frozenset", "getattr",
            "globals", "hasattr", "hash", "help", "hex", "id", "input", "int", "isinstance",
            "issubclass", "iter", "len", "list", "locals", "map", "max", "memoryview", "min",
            "next", "object", "oct", "open", "ord", "pow", "print", "property", "range",
            "repr", "reversed", "round", "set", "setattr", "slice", "sorted", "staticmethod",
            "str", "sum", "super", "tuple", "type", "vars", "zip", "__import__"
        ]
        for builtin in builtins:
            pattern = QRegularExpression(r'\b' + builtin + r'\b')
            self.highlighting_rules.append((pattern, builtin_format))

        # User-defined functions (destaque para def e chamadas)
        function_format = QTextCharFormat()
        function_format.setForeground(QColor("#dcdcaa"))
        self.highlighting_rules.append((QRegularExpression(r'\bdef\s+[a-zA-Z_][a-zA-Z0-9_]*'), function_format))
        self.highlighting_rules.append((QRegularExpression(r'\b[A-Za-z_][a-zA-Z0-9_]*\s*(?=\()'), function_format))

        # Strings (com suporte a f-strings e raw strings)
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#ce9178"))
        self.highlighting_rules.append((QRegularExpression(r'".*?"'), string_format))
        self.highlighting_rules.append((QRegularExpression(r"'.*?'"), string_format))
        self.highlighting_rules.append(
            (QRegularExpression(r'"""(?!"").*?"""', QRegularExpression.DotMatchesEverythingOption), string_format))
        self.highlighting_rules.append(
            (QRegularExpression(r"'''(?!'').*?'''", QRegularExpression.DotMatchesEverythingOption), string_format))
        # f-strings e r-strings
        self.highlighting_rules.append((QRegularExpression(r'(f|r)?".*?"'), string_format))
        self.highlighting_rules.append((QRegularExpression(r'(f|r)?\'.*?\''), string_format))

        # Comments (single line e docstrings)
        self.highlighting_rules.append((QRegularExpression(r'#.*'), self.comment_format))
        docstring_format = QTextCharFormat()
        docstring_format.setForeground(QColor("#808080"))
        self.highlighting_rules.append((QRegularExpression(r'"""[^"]*"""'), docstring_format))
        self.highlighting_rules.append((QRegularExpression(r"'''[^']*'''"), docstring_format))

        # Numbers (inteiros, floats, complexos)
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#b5cea8"))
        self.highlighting_rules.append((QRegularExpression(r'\b[0-9]+\.?[0-9]*\b'), number_format))
        self.highlighting_rules.append((QRegularExpression(r'\b0[xX][0-9a-fA-F]+\b'), number_format))  # Hex
        self.highlighting_rules.append((QRegularExpression(r'\b0[bB][01]+\b'), number_format))  # Binary
        self.highlighting_rules.append((QRegularExpression(r'\b0[oO][0-7]+\b'), number_format))  # Octal
        self.highlighting_rules.append((QRegularExpression(r'\b[0-9]+j\b'), number_format))  # Complex

        # Self e cls (para métodos de classe/instância)
        self_format = QTextCharFormat()
        self_format.setForeground(QColor("#9cdcfe"))
        self.highlighting_rules.append((QRegularExpression(r'\b(self|cls)\b'), self_format))

    def setup_javascript_rules(self):
        # Keywords
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569cd6"))
        keywords = [
            "function", "var", "let", "const", "if", "else", "for", "while",
            "do", "switch", "case", "break", "continue", "return", "try",
            "catch", "finally", "throw", "new", "delete", "typeof", "instanceof",
            "this", "true", "false", "null", "undefined", "async", "await", "export", "import"
        ]
        for word in keywords:
            pattern = QRegularExpression(r'\b' + word + r'\b')
            self.highlighting_rules.append((pattern, keyword_format))

        # Functions
        function_format = QTextCharFormat()
        function_format.setForeground(QColor("#dcdcaa"))
        self.highlighting_rules.append((QRegularExpression(r'\b[A-Za-z0-9_]+(?=\()'), function_format))

        # Strings
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#ce9178"))
        self.highlighting_rules.append((QRegularExpression(r'".*?"'), string_format))
        self.highlighting_rules.append((QRegularExpression(r"'.*?'"), string_format))
        self.highlighting_rules.append(
            (QRegularExpression(r'`.*?`', QRegularExpression.DotMatchesEverythingOption), string_format))

        # Comments
        self.highlighting_rules.append((QRegularExpression(r'//.*'), self.comment_format))
        self.highlighting_rules.append(
            (QRegularExpression(r'/\*.*?\*/', QRegularExpression.DotMatchesEverythingOption), self.comment_format))

        # Numbers
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#b5cea8"))
        self.highlighting_rules.append((QRegularExpression(r'\b[0-9]+\.?[0-9]*\b'), number_format))

    def setup_html_rules(self):
        # Tags
        tag_format = QTextCharFormat()
        tag_format.setForeground(QColor("#569cd6"))
        self.highlighting_rules.append((QRegularExpression(r'</?[a-zA-Z][^>]*>'), tag_format))

        # Attributes
        attribute_format = QTextCharFormat()
        attribute_format.setForeground(QColor("#9cdcfe"))
        self.highlighting_rules.append((QRegularExpression(r'\b[a-zA-Z-]+(?=\=)'), attribute_format))

        # Strings
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#ce9178"))
        self.highlighting_rules.append((QRegularExpression(r'"[^"]*"'), string_format))
        self.highlighting_rules.append((QRegularExpression(r"'[^']*'"), string_format))

        # Comments
        self.highlighting_rules.append(
            (QRegularExpression(r'<!--.*?-->', QRegularExpression.DotMatchesEverythingOption), self.comment_format))

    def setup_css_rules(self):
        # Properties
        property_format = QTextCharFormat()
        property_format.setForeground(QColor("#9cdcfe"))
        properties = [
            "color", "background", "font", "margin", "padding", "border",
            "width", "height", "display", "position", "float", "clear", "text-align",
            "font-size", "font-family", "line-height", "z-index", "opacity"
        ]
        for prop in properties:
            pattern = QRegularExpression(r'\b' + prop + r'\b')
            self.highlighting_rules.append((pattern, property_format))

        # Selectors
        selector_format = QTextCharFormat()
        selector_format.setForeground(QColor("#d7ba7d"))
        self.highlighting_rules.append((QRegularExpression(r'[.#]?[a-zA-Z][^{]*{'), selector_format))

        # Values
        value_format = QTextCharFormat()
        value_format.setForeground(QColor("#ce9178"))
        self.highlighting_rules.append((QRegularExpression(r':[^;]*;'), value_format))

        # Comments
        self.highlighting_rules.append(
            (QRegularExpression(r'/\*.*?\*/', QRegularExpression.DotMatchesEverythingOption), self.comment_format))

    def setup_json_rules(self):
        # Keys
        key_format = QTextCharFormat()
        key_format.setForeground(QColor("#9cdcfe"))
        self.highlighting_rules.append((QRegularExpression(r'"[^"]*"(?=\s*:)'), key_format))

        # Strings
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#ce9178"))
        self.highlighting_rules.append((QRegularExpression(r'"[^"]*"'), string_format))

        # Numbers
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#b5cea8"))
        self.highlighting_rules.append((QRegularExpression(r'\b[0-9]+\.?[0-9]*\b'), number_format))

        # Keywords
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569cd6"))
        self.highlighting_rules.append((QRegularExpression(r'\b(true|false|null)\b'), keyword_format))

    def setup_sql_rules(self):
        # Keywords
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569cd6"))
        keywords = [
            "SELECT", "FROM", "WHERE", "INSERT", "UPDATE", "DELETE", "CREATE",
            "ALTER", "DROP", "TABLE", "DATABASE", "INDEX", "VIEW", "JOIN",
            "INNER", "LEFT", "RIGHT", "OUTER", "ON", "AND", "OR", "NOT",
            "ORDER", "BY", "GROUP", "HAVING", "LIMIT", "OFFSET", "VALUES",
            "SET", "INTO", "AS", "IS", "NULL", "LIKE", "IN", "BETWEEN", "UNION"
        ]
        for word in keywords:
            pattern = QRegularExpression(r'\b' + word + r'\b', QRegularExpression.CaseInsensitiveOption)
            self.highlighting_rules.append((pattern, keyword_format))

        # Functions
        function_format = QTextCharFormat()
        function_format.setForeground(QColor("#dcdcaa"))
        functions = ["COUNT", "SUM", "AVG", "MAX", "MIN", "UPPER", "LOWER", "CONCAT", "SUBSTRING"]
        for func in functions:
            pattern = QRegularExpression(r'\b' + func + r'\b', QRegularExpression.CaseInsensitiveOption)
            self.highlighting_rules.append((pattern, function_format))

        # Strings
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#ce9178"))
        self.highlighting_rules.append((QRegularExpression(r"'.*?'"), string_format))

        # Comments
        self.highlighting_rules.append((QRegularExpression(r'--.*'), self.comment_format))
        self.highlighting_rules.append(
            (QRegularExpression(r'/\*.*?\*/', QRegularExpression.DotMatchesEverythingOption), self.comment_format))

    def setup_java_rules(self):
        # Keywords
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569cd6"))
        keywords = [
            "abstract", "assert", "boolean", "break", "byte", "case", "catch", "char", "class", "const",
            "continue", "default", "do", "double", "else", "enum", "extends", "final", "finally", "float",
            "for", "goto", "if", "implements", "import", "instanceof", "int", "interface", "long", "native",
            "new", "package", "private", "protected", "public", "return", "short", "static", "strictfp",
            "super", "switch", "synchronized", "this", "throw", "throws", "transient", "try", "void",
            "volatile", "while", "true", "false", "null"
        ]
        for word in keywords:
            pattern = QRegularExpression(r'\b' + word + r'\b')
            self.highlighting_rules.append((pattern, keyword_format))

        # Functions
        function_format = QTextCharFormat()
        function_format.setForeground(QColor("#dcdcaa"))
        self.highlighting_rules.append((QRegularExpression(r'\b[A-Za-z0-9_]+(?=\()'), function_format))

        # Strings
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#ce9178"))
        self.highlighting_rules.append((QRegularExpression(r'".*?"'), string_format))

        # Comments
        self.highlighting_rules.append((QRegularExpression(r'//.*'), self.comment_format))
        self.highlighting_rules.append(
            (QRegularExpression(r'/\*.*?\*/', QRegularExpression.DotMatchesEverythingOption), self.comment_format))

        # Numbers
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#b5cea8"))
        self.highlighting_rules.append((QRegularExpression(r'\b[0-9]+\.?[0-9]*\b'), number_format))

    def setup_cpp_rules(self):
        # Keywords
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569cd6"))
        keywords = [
            "auto", "break", "case", "char", "const", "continue", "default", "do", "double", "else", "enum",
            "extern", "float", "for", "goto", "if", "inline", "int", "long", "namespace", "new", "private",
            "protected", "public", "register", "return", "short", "signed", "sizeof", "static", "struct",
            "switch", "template", "this", "throw", "try", "typedef", "union", "unsigned", "virtual", "void",
            "volatile", "while", "class", "true", "false", "nullptr"
        ]
        for word in keywords:
            pattern = QRegularExpression(r'\b' + word + r'\b')
            self.highlighting_rules.append((pattern, keyword_format))

        # Functions
        function_format = QTextCharFormat()
        function_format.setForeground(QColor("#dcdcaa"))
        self.highlighting_rules.append((QRegularExpression(r'\b[A-Za-z0-9_]+(?=\()'), function_format))

        # Strings
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#ce9178"))
        self.highlighting_rules.append((QRegularExpression(r'".*?"'), string_format))
        self.highlighting_rules.append((QRegularExpression(r"R\".*?\""), string_format))

        # Comments
        self.highlighting_rules.append((QRegularExpression(r'//.*'), self.comment_format))
        self.highlighting_rules.append(
            (QRegularExpression(r'/\*.*?\*/', QRegularExpression.DotMatchesEverythingOption), self.comment_format))

        # Numbers
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#b5cea8"))
        self.highlighting_rules.append((QRegularExpression(r'\b[0-9]+\.?[0-9]*\b'), number_format))

    def setup_csharp_rules(self):
        # Keywords (similar to Java/C++)
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569cd6"))
        keywords = [
            "abstract", "as", "base", "bool", "break", "byte", "case", "catch", "char", "checked", "class",
            "const", "continue", "decimal", "default", "delegate", "do", "double", "else", "enum", "event",
            "explicit", "extern", "false", "finally", "fixed", "float", "for", "foreach", "goto", "if", "implicit",
            "in", "int", "interface", "internal", "is", "lock", "long", "namespace", "new", "null", "object",
            "operator", "out", "override", "params", "private", "protected", "public", "readonly", "ref",
            "return", "sbyte", "sealed", "short", "sizeof", "stackalloc", "static", "string", "struct", "switch",
            "this", "throw", "true", "try", "typeof", "uint", "ulong", "unchecked", "unsafe", "ushort", "using",
            "virtual", "void", "volatile", "while"
        ]
        for word in keywords:
            pattern = QRegularExpression(r'\b' + word + r'\b')
            self.highlighting_rules.append((pattern, keyword_format))

        # Functions
        function_format = QTextCharFormat()
        function_format.setForeground(QColor("#dcdcaa"))
        self.highlighting_rules.append((QRegularExpression(r'\b[A-Za-z0-9_]+(?=\()'), function_format))

        # Strings
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#ce9178"))
        self.highlighting_rules.append((QRegularExpression(r'".*?"'), string_format))
        self.highlighting_rules.append((QRegularExpression(r'@".*?"'), string_format))

        # Comments
        self.highlighting_rules.append((QRegularExpression(r'//.*'), self.comment_format))
        self.highlighting_rules.append(
            (QRegularExpression(r'/\*.*?\*/', QRegularExpression.DotMatchesEverythingOption), self.comment_format))

        # Numbers
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#b5cea8"))
        self.highlighting_rules.append((QRegularExpression(r'\b[0-9]+\.?[0-9]*\b'), number_format))

    def setup_php_rules(self):
        # Keywords
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569cd6"))
        keywords = [
            "abstract", "and", "array", "as", "break", "callable", "case", "catch", "class", "clone", "const",
            "continue", "declare", "default", "die", "do", "echo", "else", "elseif", "empty", "enddeclare",
            "endfor", "endforeach", "endif", "endswitch", "endwhile", "eval", "exit", "extends", "final",
            "finally", "for", "foreach", "function", "global", "goto", "if", "implements", "include", "include_once",
            "instanceof", "insteadof", "interface", "isset", "list", "namespace", "new", "or", "print", "private",
            "protected", "public", "require", "require_once", "return", "static", "switch", "throw", "trait",
            "try", "unset", "use", "var", "while", "xor", "yield", "true", "false", "null"
        ]
        for word in keywords:
            pattern = QRegularExpression(r'\b' + word + r'\b')
            self.highlighting_rules.append((pattern, keyword_format))

        # Functions
        function_format = QTextCharFormat()
        function_format.setForeground(QColor("#dcdcaa"))
        self.highlighting_rules.append((QRegularExpression(r'\b[A-Za-z0-9_]+(?=\()'), function_format))

        # Strings
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#ce9178"))
        self.highlighting_rules.append((QRegularExpression(r'".*?"'), string_format))
        self.highlighting_rules.append((QRegularExpression(r"'.*?'"), string_format))

        # Comments
        self.highlighting_rules.append((QRegularExpression(r'//.*'), self.comment_format))
        self.highlighting_rules.append((QRegularExpression(r'#.*'), self.comment_format))
        self.highlighting_rules.append(
            (QRegularExpression(r'/\*.*?\*/', QRegularExpression.DotMatchesEverythingOption), self.comment_format))

    def setup_ruby_rules(self):
        # Keywords
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569cd6"))
        keywords = [
            "begin", "break", "case", "class", "def", "do", "else", "elsif", "end", "ensure",
            "false", "for", "if", "in", "module", "nil", "not", "or", "redo", "rescue",
            "retry", "return", "self", "super", "then", "true", "unless", "until", "when",
            "while", "yield", "alias", "and", "BEGIN", "defined?", "END", "next", "raise",
            "require", "rescue", "attr", "attr_accessor", "attr_reader", "attr_writer"
        ]
        for word in keywords:
            pattern = QRegularExpression(r'\b' + word + r'\b')
            self.highlighting_rules.append((pattern, keyword_format))

        # Functions/Methods
        function_format = QTextCharFormat()
        function_format.setForeground(QColor("#dcdcaa"))
        self.highlighting_rules.append((QRegularExpression(r'\bdef\s+[a-zA-Z_][a-zA-Z0-9_]*'), function_format))

        # Strings
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#ce9178"))
        self.highlighting_rules.append((QRegularExpression(r'"[^"]*"'), string_format))
        self.highlighting_rules.append((QRegularExpression(r"'[^']*'"), string_format))
        self.highlighting_rules.append((QRegularExpression(r'%[qQw]{[^}]*}'), string_format))

        # Comments
        self.highlighting_rules.append((QRegularExpression(r'#.*'), self.comment_format))

        # Numbers
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#b5cea8"))
        self.highlighting_rules.append((QRegularExpression(r'\b[0-9]+\.?[0-9]*\b'), number_format))

    def setup_go_rules(self):
        # Keywords
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569cd6"))
        keywords = [
            "break", "default", "func", "interface", "select", "case", "defer", "go", "map", "struct",
            "chan", "else", "goto", "package", "switch", "const", "fallthrough", "if", "range", "type",
            "continue", "for", "import", "return", "var", "true", "false", "nil"
        ]
        for word in keywords:
            pattern = QRegularExpression(r'\b' + word + r'\b')
            self.highlighting_rules.append((pattern, keyword_format))

        # Functions
        function_format = QTextCharFormat()
        function_format.setForeground(QColor("#dcdcaa"))
        self.highlighting_rules.append((QRegularExpression(r'\bfunc\s+[a-zA-Z_][a-zA-Z0-9_]*'), function_format))

        # Strings
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#ce9178"))
        self.highlighting_rules.append((QRegularExpression(r'"[^"]*"'), string_format))
        self.highlighting_rules.append((QRegularExpression(r"`[^`]*`"), string_format))

        # Comments
        self.highlighting_rules.append((QRegularExpression(r'//.*'), self.comment_format))
        self.highlighting_rules.append(
            (QRegularExpression(r'/\*.*?\*/', QRegularExpression.DotMatchesEverythingOption), self.comment_format))

        # Numbers
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#b5cea8"))
        self.highlighting_rules.append((QRegularExpression(r'\b[0-9]+\.?[0-9]*\b'), number_format))

    def setup_rust_rules(self):
        # Keywords
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569cd6"))
        keywords = [
            "as", "break", "const", "continue", "crate", "else", "enum", "extern", "false", "fn", "for",
            "if", "impl", "in", "let", "loop", "match", "mod", "move", "mut", "pub", "ref", "return",
            "self", "Self", "static", "struct", "super", "true", "trait", "type", "unsafe", "use",
            "where", "while", "dyn", "abstract", "become", "box", "do", "final", "macro", "override",
            "priv", "typeof", "unsized", "virtual", "yield"
        ]
        for word in keywords:
            pattern = QRegularExpression(r'\b' + word + r'\b')
            self.highlighting_rules.append((pattern, keyword_format))

        # Functions
        function_format = QTextCharFormat()
        function_format.setForeground(QColor("#dcdcaa"))
        self.highlighting_rules.append((QRegularExpression(r'\bfn\s+[a-zA-Z_][a-zA-Z0-9_]*'), function_format))

        # Strings
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#ce9178"))
        self.highlighting_rules.append((QRegularExpression(r'r"[^"]*"'), string_format))
        self.highlighting_rules.append((QRegularExpression(r'"[^"]*"'), string_format))

        # Comments
        self.highlighting_rules.append((QRegularExpression(r'//.*'), self.comment_format))
        self.highlighting_rules.append(
            (QRegularExpression(r'/\*.*?\*/', QRegularExpression.DotMatchesEverythingOption), self.comment_format))

        # Numbers
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#b5cea8"))
        self.highlighting_rules.append((QRegularExpression(r'\b[0-9]+\.?[0-9]*\b'), number_format))

    def setup_swift_rules(self):
        # Keywords
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569cd6"))
        keywords = [
            "associatedtype", "class", "deinit", "enum", "extension", "fileprivate", "func", "import", "init",
            "inout", "internal", "let", "open", "operator", "private", "protocol", "public", "static",
            "struct", "subscript", "typealias", "var", "break", "case", "continue", "default", "defer",
            "do", "else", "fallthrough", "for", "guard", "if", "in", "repeat", "return", "switch", "where",
            "while", "as", "catch", "false", "is", "nil", "rethrows", "super", "self", "Self", "throw",
            "throws", "true", "try", "try?"
        ]
        for word in keywords:
            pattern = QRegularExpression(r'\b' + word + r'\b')
            self.highlighting_rules.append((pattern, keyword_format))

        # Functions
        function_format = QTextCharFormat()
        function_format.setForeground(QColor("#dcdcaa"))
        self.highlighting_rules.append((QRegularExpression(r'\bfunc\s+[a-zA-Z_][a-zA-Z0-9_]*'), function_format))

        # Strings
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#ce9178"))
        self.highlighting_rules.append((QRegularExpression(r'"[^"]*"'), string_format))

        # Comments
        self.highlighting_rules.append((QRegularExpression(r'//.*'), self.comment_format))
        self.highlighting_rules.append(
            (QRegularExpression(r'/\*.*?\*/', QRegularExpression.DotMatchesEverythingOption), self.comment_format))

        # Numbers
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#b5cea8"))
        self.highlighting_rules.append((QRegularExpression(r'\b[0-9]+\.?[0-9]*\b'), number_format))

    def setup_kotlin_rules(self):
        # Keywords
        keyword_format = QTextCharFormat()
        keyword_format.setForeground(QColor("#569cd6"))
        keywords = [
            "abstract", "annotation", "as", "break", "by", "catch", "class", "companion", "const", "constructor",
            "continue", "data", "do", "else", "enum", "expect", "external", "false", "final", "finally",
            "for", "fun", "if", "import", "in", "inline", "inner", "interface", "internal", "is", "lateinit",
            "lazy", "native", "null", "object", "open", "operator", "out", "override", "package", "private",
            "property", "protected", "public", "receiver", "reified", "return", "sealed", "self", "super",
            "suspend", "tailrec", "this", "throw", "true", "try", "typealias", "typeof", "val", "var",
            "when", "where", "while"
        ]
        for word in keywords:
            pattern = QRegularExpression(r'\b' + word + r'\b')
            self.highlighting_rules.append((pattern, keyword_format))

        # Functions
        function_format = QTextCharFormat()
        function_format.setForeground(QColor("#dcdcaa"))
        self.highlighting_rules.append((QRegularExpression(r'\bfun\s+[a-zA-Z_][a-zA-Z0-9_]*'), function_format))

        # Strings
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#ce9178"))
        self.highlighting_rules.append((QRegularExpression(r'"[^"]*"'), string_format))
        self.highlighting_rules.append((QRegularExpression(r"'''[^''']*'''"), string_format))

        # Comments
        self.highlighting_rules.append((QRegularExpression(r'//.*'), self.comment_format))
        self.highlighting_rules.append(
            (QRegularExpression(r'/\*.*?\*/', QRegularExpression.DotMatchesEverythingOption), self.comment_format))

        # Numbers
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#b5cea8"))
        self.highlighting_rules.append((QRegularExpression(r'\b[0-9]+\.?[0-9]*\b'), number_format))

    def setup_xml_rules(self):
        # Tags
        tag_format = QTextCharFormat()
        tag_format.setForeground(QColor("#569cd6"))
        self.highlighting_rules.append((QRegularExpression(r'</?[a-zA-Z][^>]*>'), tag_format))

        # Attributes
        attribute_format = QTextCharFormat()
        attribute_format.setForeground(QColor("#9cdcfe"))
        self.highlighting_rules.append((QRegularExpression(r'\b[a-zA-Z-]+(?=\s*=)'), attribute_format))

        # Strings
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#ce9178"))
        self.highlighting_rules.append((QRegularExpression(r'"[^"]*"'), string_format))
        self.highlighting_rules.append((QRegularExpression(r"'[^']*'"), string_format))

        # Comments
        self.highlighting_rules.append(
            (QRegularExpression(r'<!--.*?-->', QRegularExpression.DotMatchesEverythingOption), self.comment_format))

    def setup_markdown_rules(self):
        # Headers
        header_format = QTextCharFormat()
        header_format.setForeground(QColor("#569cd6"))
        for level in range(1, 7):
            self.highlighting_rules.append((QRegularExpression(rf'^{{#{{{level}}}}}\s+'), header_format))

        # Bold/Italic
        bold_format = QTextCharFormat()
        bold_format.setForeground(QColor("#dcdcaa"))
        self.highlighting_rules.append((QRegularExpression(r'\*\*.*?\*\*'), bold_format))
        self.highlighting_rules.append((QRegularExpression(r'__.*?__'), bold_format))

        italic_format = QTextCharFormat()
        italic_format.setForeground(QColor("#ce9178"))
        self.highlighting_rules.append((QRegularExpression(r'\*.*?\*'), italic_format))
        self.highlighting_rules.append((QRegularExpression(r'_.*?_'), italic_format))

        # Code
        code_format = QTextCharFormat()
        code_format.setForeground(QColor("#b5cea8"))
        self.highlighting_rules.append((QRegularExpression(r'`(.*?)`'), code_format))
        self.highlighting_rules.append(
            (QRegularExpression(r'```[\s\S]*?```', QRegularExpression.DotMatchesEverythingOption), code_format))

    def setup_yaml_rules(self):
        # Keys
        key_format = QTextCharFormat()
        key_format.setForeground(QColor("#9cdcfe"))
        self.highlighting_rules.append((QRegularExpression(r'^[a-zA-Z0-9_-]+:'), key_format))

        # Strings
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#ce9178"))
        self.highlighting_rules.append((QRegularExpression(r'"[^"]*"'), string_format))
        self.highlighting_rules.append((QRegularExpression(r"'[^']*'"), string_format))

        # Numbers
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#b5cea8"))
        self.highlighting_rules.append((QRegularExpression(r'\b[0-9]+\.?[0-9]*\b'), number_format))

        # Comments
        self.highlighting_rules.append((QRegularExpression(r'#.*'), self.comment_format))

    def setup_basic_rules(self):
        # Strings básicas para linguagens não específicas
        string_format = QTextCharFormat()
        string_format.setForeground(QColor("#ce9178"))
        self.highlighting_rules.append((QRegularExpression(r'"[^"]*"'), string_format))
        self.highlighting_rules.append((QRegularExpression(r"'[^']*'"), string_format))

        # Números
        number_format = QTextCharFormat()
        number_format.setForeground(QColor("#b5cea8"))
        self.highlighting_rules.append((QRegularExpression(r'\b[0-9]+\.?[0-9]*\b'), number_format))

    def highlightBlock(self, text):
        for pattern, format in self.highlighting_rules:
            iterator = pattern.globalMatch(text)
            while iterator.hasNext():
                match = iterator.next()
                self.setFormat(match.capturedStart(), match.capturedLength(), format)

        # Aplica highlights de erro/aviso (mantido do código original)
        data = self.currentBlockUserData()
        if isinstance(data, ErrorData) and data.errors:
            for error in data.errors:
                if error['type'] == 'error':
                    error_format = QTextCharFormat()
                    error_format.setBackground(QColor(255, 0, 0, 128))
                    self.setFormat(0, len(text), error_format)
                elif error['type'] == 'warning':
                    warning_format = QTextCharFormat()
                    warning_format.setBackground(QColor(255, 255, 0, 128))
                    self.setFormat(0, len(text), warning_format)
