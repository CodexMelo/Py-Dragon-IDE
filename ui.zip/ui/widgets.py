import os
import re
import time
import threading
import subprocess
import json
import ast
import importlib.util
from typing import Dict, Set, List, Any

from PySide6.QtWidgets import (
    QPlainTextEdit, QListWidget, QListWidgetItem, QWidget,
    QVBoxLayout, QHBoxLayout, QLabel, QProgressBar, QPushButton
)
from PySide6.QtGui import (
    QPainter, QColor, QFont, QTextCursor, QKeyEvent,
    QTextBlockUserData, QTextOption, QFontMetrics
)
from PySide6.QtCore import Qt, QTimer, QThread, Signal, QProcess

from .syntax_highlighter import PythonHighlighter
from .theme import DarkTheme
from ..features.autocomplete import AutoCompleteManager, ModuleCacheManager
from ..utils.language_syntax import LanguageSyntaxManager

# Importar todos os widgets UI
from .code_editor import CodeEditor
from .line_number_area import LineNumberArea
from .auto_complete_widget import AutoCompleteWidget
from .terminal import TerminalTextEdit
from .status_progress import StatusBarProgress
from .minimap import Minimap

__all__ = [
    'CodeEditor',
    'LineNumberArea',
    'AutoCompleteWidget',
    'TerminalTextEdit',
    'StatusBarProgress',
    'Minimap'
]