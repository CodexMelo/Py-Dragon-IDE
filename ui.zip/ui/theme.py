"""
Configurações de tema para o IDE
"""
from PySide6.QtGui import QPalette, QColor
from PySide6.QtWidgets import QApplication


def apply_dark_theme():
    """Aplica o tema escuro otimizado para programação"""
    palette = QPalette()

    # Cores base
    dark_bg = QColor(30, 30, 30)
    darker_bg = QColor(20, 20, 20)
    light_text = QColor(220, 220, 220)
    highlight = QColor(86, 156, 214)
    highlight_text = QColor(255, 255, 255)

    # Configuração da paleta
    palette.setColor(QPalette.Window, dark_bg)
    palette.setColor(QPalette.WindowText, light_text)
    palette.setColor(QPalette.Base, darker_bg)
    palette.setColor(QPalette.AlternateBase, dark_bg)
    palette.setColor(QPalette.ToolTipBase, dark_bg)
    palette.setColor(QPalette.ToolTipText, light_text)
    palette.setColor(QPalette.Text, light_text)
    palette.setColor(QPalette.Button, dark_bg)
    palette.setColor(QPalette.ButtonText, light_text)
    palette.setColor(QPalette.BrightText, QColor(255, 0, 0))
    palette.setColor(QPalette.Link, highlight)
    palette.setColor(QPalette.Highlight, highlight)
    palette.setColor(QPalette.HighlightedText, highlight_text)

    # Cores para estados desabilitados
    palette.setColor(QPalette.Disabled, QPalette.Text, QColor(127, 127, 127))
    palette.setColor(QPalette.Disabled, QPalette.ButtonText, QColor(127, 127, 127))

    QApplication.setPalette(palette)
    QApplication.setStyle("Fusion")

    # CSS adicional
    app = QApplication.instance()
    app.setStyleSheet("""
        QMainWindow {
            background-color: #1e1e1e;
        }
        QMenuBar {
            background-color: #2d2d30;
            color: #cccccc;
            border: none;
        }
        QMenuBar::item:selected {
            background-color: #3e3e42;
        }
        QMenu {
            background-color: #2d2d30;
            color: #cccccc;
            border: 1px solid #3e3e42;
        }
        QMenu::item:selected {
            background-color: #3e3e42;
        }
        QToolBar {
            background-color: #2d2d30;
            border: none;
            spacing: 3px;
        }
        QToolButton {
            background-color: transparent;
            border: 1px solid transparent;
            border-radius: 3px;
            padding: 4px;
        }
        QToolButton:hover {
            background-color: #3e3e42;
            border: 1px solid #505050;
        }
        QStatusBar {
            background-color: #007acc;
            color: white;
        }
        QDockWidget {
            titlebar-close-icon: url(close.png);
            titlebar-normal-icon: url(float.png);
        }
        QDockWidget::title {
            background-color: #2d2d30;
            padding: 4px 8px;
            text-align: left;
            font-weight: bold;
        }
    """)


def apply_light_theme():
    """Aplica o tema claro"""
    palette = QPalette()
    palette.setColor(QPalette.Window, QColor(240, 240, 240))
    palette.setColor(QPalette.WindowText, QColor(0, 0, 0))
    palette.setColor(QPalette.Base, QColor(255, 255, 255))
    palette.setColor(QPalette.Text, QColor(0, 0, 0))
    QApplication.setPalette(palette)