from PySide6.QtWidgets import QPlainTextEdit
from PySide6.QtGui import QKeyEvent, QTextCursor, QFont
from PySide6.QtCore import Qt, QTimer

from .line_number_area import LineNumberArea
from .auto_complete_widget import AutoCompleteWidget
from ..features.autocomplete import AutoCompleteWorker
class CodeEditor(QPlainTextEdit):
    def __init__(self, text, cursor_position, file_path, project_path, parent=None):
        super().__init__(parent)

        # Configurações básicas
        self.setPlainText(text)
        cursor = self.textCursor()
        cursor.setPosition(min(cursor_position, len(text)))
        self.setTextCursor(cursor)

        self.file_path = file_path
        self.project_path = project_path

        # Configurar tab
        self.configure_tab_stop()

        # Inicializar componentes de autocomplete
        self.auto_complete_widget = AutoCompleteWidget(self)
        self.auto_complete_timer = QTimer(self)
        self.auto_complete_timer.setSingleShot(True)
        self.auto_complete_timer.timeout.connect(self.trigger_auto_complete)
        self.auto_complete_worker = None
        self.completer = QCompleter()
        self.completer.setWidget(self)
        self.completer.activated.connect(self.insert_completion)

        # Configurações visuais
        self.setFont(QFont("Monospace", 12))
        self.setWordWrapMode(QTextOption.NoWrap)

        # Cache para melhor performance
        self.last_suggestions = []
        self.last_word = ""

    def fix_indentation(self):
        """Auto-corrige indentação inconsistente no texto atual"""
        text = self.toPlainText()
        try:
            # Dedent e reindent com 4 espaços
            dedented = textwrap.dedent(text)
            lines = dedented.splitlines()
            fixed_lines = []
            for line in lines:
                indent_level = len(line) - len(line.lstrip(' \t'))
                fixed_line = ' ' * (indent_level * 4) + line.lstrip(' \t')
                fixed_lines.append(fixed_line)
            fixed_text = '\n'.join(fixed_lines)
            self.setPlainText(fixed_text)
            print("Indentação corrigida automaticamente!")
        except Exception as e:
            print(f"Falha na correção de indent: {e}")



    def configure_tab_stop(self):
        """Configura o tamanho do tab baseado no tipo de arquivo"""
        font = QFont("Monospace", 12)
        self.setFont(font)
        font_metrics = self.fontMetrics()

        # Para arquivos Python, usa 4 espaços (padrão Python)
        if self.file_path and self.file_path.endswith('.py'):
            tab_width = font_metrics.horizontalAdvance(' ') * 4  # 4 espaços
        else:
            tab_width = font_metrics.horizontalAdvance(' ') * 2  # 2 espaços para outros arquivos

        self.setTabStopDistance(tab_width)

    def keyPressEvent(self, event: QKeyEvent):
        # CORREÇÃO: Adicionar try-except global para prevenir crashes
        try:
            # NOVO: Atalhos para forçar autocomplete
            if event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_Space:
                self.force_auto_complete()
                event.accept()
                return

            # Fecha o autocomplete se Escape for pressionado
            if event.key() == Qt.Key_Escape and self.auto_complete_widget.isVisible():
                self.auto_complete_widget.hide()
                event.accept()
                return

            # Navega no autocomplete com setas
            if self.auto_complete_widget.isVisible():
                if event.key() in (Qt.Key_Up, Qt.Key_Down, Qt.Key_Return, Qt.Key_Enter):
                    if event.key() == Qt.Key_Return or event.key() == Qt.Key_Enter:
                        current_item = self.auto_complete_widget.currentItem()
                        if current_item:
                            self.auto_complete_widget.insert_completion(current_item.text())
                        event.accept()
                        return
                    elif event.key() == Qt.Key_Up:
                        current_row = self.auto_complete_widget.currentRow()
                        self.auto_complete_widget.setCurrentRow(max(0, current_row - 1))
                        event.accept()
                        return
                    elif event.key() == Qt.Key_Down:
                        current_row = self.auto_complete_widget.currentRow()
                        self.auto_complete_widget.setCurrentRow(
                            min(self.auto_complete_widget.count() - 1, current_row + 1))
                        event.accept()
                        return

            # NOVO: Trigger muito mais sensível - qualquer tecla relevante
            current_text = self.toPlainText()
            cursor = self.textCursor()
            cursor_position = cursor.position()

            # Verificação ultra-rápida se deve mostrar autocomplete - CORREÇÃO: com try-except
            try:
                lines = current_text[:cursor_position].split('\n')
                current_line = lines[-1] if lines else ""
                current_word = self.get_current_word_fast(current_line)

                # Trigger em quase qualquer tecla (exceto modificadoras)
                trigger_keys = [
                    Qt.Key_A, Qt.Key_B, Qt.Key_C, Qt.Key_D, Qt.Key_E, Qt.Key_F, Qt.Key_G, Qt.Key_H,
                    Qt.Key_I, Qt.Key_J, Qt.Key_K, Qt.Key_L, Qt.Key_M, Qt.Key_N, Qt.Key_O, Qt.Key_P,
                    Qt.Key_Q, Qt.Key_R, Qt.Key_S, Qt.Key_T, Qt.Key_U, Qt.Key_V, Qt.Key_W, Qt.Key_X,
                    Qt.Key_Y, Qt.Key_Z, Qt.Key_Underscore, Qt.Key_Period
                ]

                # Mostra autocomplete em qualquer letra, underline ou ponto
                should_trigger = (
                        event.key() in trigger_keys or
                        event.text().isalpha() or
                        event.text() == '_' or
                        event.text() == '.' or
                        event.key() == Qt.Key_Backspace
                )

                # NOVO: Trigger especial para pontos (métodos de módulos)
                if event.text() == '.':
                    # Dispara autocomplete imediatamente após ponto
                    self.auto_complete_timer.start(10)  # Quase instantâneo para pontos

                # Não mostra em casos específicos - CORREÇÃO: com verificação segura
                if should_trigger:
                    is_inside_str = self.is_inside_string(current_text, cursor_position)
                    is_inside_cmt = self.is_inside_comment(current_line)  # AGORA SEGURO

                    if (not is_inside_str and not is_inside_cmt and len(current_word) >= 1):
                        self.auto_complete_timer.start(50)  # REDUZIDO PARA 50ms - QUASE INSTANTÂNEO

            except Exception as e:
                # Em caso de erro na análise, simplesmente não mostra autocomplete
                print(f"Erro na análise do contexto: {e}")

            super().keyPressEvent(event)

        except Exception as e:
            # CORREÇÃO CRÍTICA: Prevenir crash total
            print(f"Erro crítico no keyPressEvent: {e}")
            # Fallback: chama o método pai para garantir funcionalidade básica
            super().keyPressEvent(event)
    def get_current_word_fast(self, current_line):
        """Extrai palavra atual de forma ultra-rápida - CORREÇÃO SEGURA"""
        if not current_line or not current_line.strip():
            return ""

        try:
            # Busca reversa simples para palavra completa
            line = current_line.rstrip()

            # Caso especial para cadeias com pontos
            if '.' in line:
                parts = line.split('.')
                # Se termina com ponto, quer tudo do último objeto
                if line.endswith('.'):
                    return ""  # Mostra todas as sugestões
                else:
                    return parts[-1] if parts else ""

            # Palavra simples - CORREÇÃO: método mais seguro
            words = line.split()
            return words[-1] if words else ""
        except Exception:
            return ""
    def force_auto_complete(self):
        """Força autocomplete imediatamente"""
        # Para worker anterior rapidamente
        if self.auto_complete_worker and self.auto_complete_worker.isRunning():
            self.auto_complete_worker.stop()
            self.auto_complete_worker.wait(10)  # Timeout muito curto

        # Dispara autocomplete imediatamente
        self.trigger_auto_complete()

    def trigger_auto_complete(self):
        """Dispara autocomplete de forma otimizada - CORREÇÃO SEGURA"""
        try:
            cursor = self.textCursor()
            cursor_position = cursor.position()
            text = self.toPlainText()
            selected_text = cursor.selectedText()

            # Verificação ultra-rápida - CORREÇÃO: com try-except
            try:
                lines = text[:cursor_position].split('\n')
                current_line = lines[-1] if lines else ""
                current_word = self.get_current_word_fast(current_line)

                # Força rescan se necessário (após ponto, por exemplo)
                if current_line.endswith('.'):
                    base_obj = current_line.split('.')[-2].split()[-1] if '.' in current_line else ""
                    if base_obj:
                        module_cache_manager.force_rescan(base_obj, self.file_path)

                # Não mostra em casos específicos - CORREÇÃO: com verificação segura
                is_inside_str = self.is_inside_string(text, cursor_position)
                is_inside_cmt = self.is_inside_comment(current_line)  # AGORA SEGURO

                if is_inside_str or is_inside_cmt:
                    self.auto_complete_widget.hide()
                    return

            except Exception as e:
                print(f"Erro na verificação do contexto: {e}")
                self.auto_complete_widget.hide()
                return

            # Obtém contexto
            tab = self.parent()
            ide = None
            while tab and not isinstance(tab, EditorTab):
                tab = tab.parent()

            if tab:
                ide = tab.get_ide()

            if ide and tab and tab.file_path:
                # Para worker anterior rapidamente
                if self.auto_complete_worker and self.auto_complete_worker.isRunning():
                    self.auto_complete_worker.stop()
                    self.auto_complete_worker.wait(10)

                # Worker otimizado
                self.auto_complete_worker = AutoCompleteWorker(
                    text, cursor_position, tab.file_path, ide.project_path, selected_text
                )
                self.auto_complete_worker.finished.connect(self.show_auto_complete)
                self.auto_complete_worker.start()

        except Exception as e:
            print(f"Erro no trigger_auto_complete: {e}")
            self.auto_complete_widget.hide()

    def is_inside_string(self, text, position):
        """Verifica se está dentro de string de forma otimizada - MELHORADO"""
        # Conta quotes não escapados
        single_count = 0
        double_count = 0
        for i, char in enumerate(text[:position]):
            if char == "'" and (i == 0 or text[i-1] != '\\'):
                single_count += 1
            elif char == '"' and (i == 0 or text[i-1] != '\\'):
                double_count += 1
        return (single_count % 2 == 1) or (double_count % 2 == 1)

    def is_inside_comment(self, current_line):
        """Verifica se está em comentário - CORREÇÃO DEFINITIVA"""
        if not current_line or not current_line.strip():
            return False

        try:
            # CORREÇÃO: Verifica simplesmente se há '#' em qualquer parte da linha
            # Não precisa splitar ou acessar índices
            return '#' in current_line
        except Exception:
            return False

    def show_auto_complete(self, suggestions):
        """Mostra sugestões instantaneamente"""
        if suggestions:
            self.auto_complete_widget.show_suggestions(self, suggestions)
            # Cache das sugestões para reutilização
            self.last_suggestions = suggestions
        else:
            self.auto_complete_widget.hide()

    def insert_completion(self, completion):
        """Insere completion rapidamente"""
        cursor = self.textCursor()

        if cursor.hasSelection():
            cursor.removeSelectedText()

        cursor.insertText(completion)
        self.auto_complete_widget.hide()
